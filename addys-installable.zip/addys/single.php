<?php
/**
 * The template for displaying all single posts
 */

get_header(); ?>

	<?php /* The loop */ ?>
	<?php while ( have_posts() ) : the_post(); ?>

		<?php

		get_template_part( 'content' );
		?>
<div class="postoddy">

		<?php
		do_action( 'secretlab_theme_blog_post_author' );
		do_action( 'secretlab_theme_blog_post_nav' );

		?>
		<?php
		do_action( 'secretlab_theme_blog_show_postmore' );
		?>
		<?php comments_template(); ?>
</div>
	<?php endwhile; ?>

<?php get_footer(); ?>
