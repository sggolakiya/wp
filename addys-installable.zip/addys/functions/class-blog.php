<?php
/**
 * The class contain blog functions.
 */

class Secret_Lab_Blog {

    public function __construct() {

        add_action( 'secretlab_theme_blog_number_of_columns', array( 'Secret_Lab_Blog', 'number_of_columns' ) );
        add_action( 'secretlab_theme_blog_thumb', array( 'Secret_Lab_Blog', 'thumb_size' ) );

	    add_action( 'secretlab_theme_blog_entry_meta_header', array( 'Secret_Lab_Blog', 'entry_meta_header' ) );
	    add_action( 'secretlab_theme_blog_entry_meta', array( 'Secret_Lab_Blog', 'entry_meta' ) );

	    add_action( 'secretlab_theme_blog_read_more', array( 'Secret_Lab_Blog', 'read_more' ) );

	    add_action( 'secretlab_theme_blog_tags', array( 'Secret_Lab_Blog', 'tags' ) );

	    add_action( 'secretlab_theme_blog_post_nav', array( 'Secret_Lab_Blog', 'post_nav' ) );
	    add_action( 'secretlab_theme_blog_post_author', array( 'Secret_Lab_Blog', 'post_author' ) );

	    add_action( 'secretlab_theme_blog_show_postmore', array( 'Secret_Lab_Blog', 'show_postmore' ) );
	    add_action( 'secretlab_theme_blog_cat_list', array( 'Secret_Lab_Blog', 'cat_list' ) );

        add_filter( 'comment_form_default_fields', array( $this, 'update_comments_fields' ) );
        add_filter( 'comment_form_defaults', array( $this, 'update_comment_field' ) );

    }

    public static function show_postmore() {
        global $secretlab;
        if ( isset( $secretlab['is_related_posts'] ) ) {
            if ( '1' === $secretlab['is_related_posts'] ) {
                self::postmore_query();
            }
        }
    }
	public static function post_author() {
		global $post, $secretlab;
		if ( isset( $secretlab['show_post_author'] ) ) {
			if ( '1' === $secretlab['show_post_author'] ) {
				$user_description = get_the_author_meta( 'description' );

				echo '<div class="author_info author vcard" itemprop="author" itemscope="" itemtype="//schema.org/Person">

	<div class="author_avatar" itemprop="image">'.get_avatar( get_the_author_meta( 'user_email' ), 150 ).'</div>

	<div class="author_description">
		<h5 class="author_title" itemprop="name">'.get_the_author().'</h5>

		<div class="author_bio" itemprop="description">
			<p>'.$user_description.'</p>
			<a class="author_link" href="'.esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ).'" rel="author">'.esc_html__('View all posts by', 'addys').' <span class="author_name">'.get_the_author().'</span></a>
		</div>
	</div>

</div>';
			}
		}
	}

	public static function cat_list() {
		global $post, $secretlab;
		// Categories: used between list items, there is a space after the comma.
		if ( isset( $secretlab['show_post_category'] ) ) {
			if ( '0' != $secretlab['show_post_category'] ) {
				echo get_the_category_list( '', 'multiple', $post->ID );
			}
		} else {
			echo get_the_category_list( '', 'multiple', $post->ID );
		}
	}

    public static function postmore_query() {
        global $post, $secretlab;
	    $rmore = '';
	    if ( ! empty( $secretlab['read_more_text'] ) ) { $rmore = $secretlab['read_more_text'];}
	    $backup = $post;
        $tags   = wp_get_post_tags( $post->ID );
        if ( $tags ) {
            $tag_ids = array();
            foreach ( $tags as $individual_tag ) {
                $tag_ids[] = $individual_tag->term_id;
            }

            $args     = array(
                'tag__in'      => $tag_ids,
                'post__not_in' => array( $post->ID ),
                'showposts'    =>3, // Number of related posts that will be shown.
            );
            $my_query = new WP_Query( $args );
            if( $my_query->have_posts() ) {
                echo '<div class="related">';
                if ( !empty( $secretlab['related_posts_title'] ) ) {
	                echo '<h2>' . esc_html( $secretlab['related_posts_title'] ) . '</h2>';
                }

                while ( $my_query->have_posts() ) {
                    $my_query->the_post();
	                echo '<div class="rblock">
                        <div class="thumb">';
                                if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
                                    the_post_thumbnail( 'atiframebuilder_rectangle' );
                                }
                                if ( '1' === $secretlab['show_post_category'] ) {
                                    echo get_the_category_list( '', 'single', $post->ID );
                                }
                            echo '<div><a href="'.get_the_permalink().'" rel="bookmark"><img src="' . esc_url( get_template_directory_uri() ) . '/images/eye.svg" alt="'.esc_attr__( 'Full Post', 'addys' ).'"></a></div>
                        </div>
                        <div class="wr"><h5><a href="' , get_the_permalink() , '" title="' , get_the_title() , '">' , get_the_title() , '</a></h5>
<div class="descr">'.get_the_excerpt().'</div>
                        <div class="entry-meta"><span class="date"><i></i> ' , get_the_date() , '</span></div>';

				    echo '<a href="', get_the_permalink(), '" rel="bookmark" class="rmore">', esc_html( $rmore ), '</a>';

	                echo '
                        </div>
                    </div>';
                }
                echo '</div>';
            }
        }
        $post = $backup;
        wp_reset_postdata();
    }

    // Read more link for post feed
    public static function read_more() {
        global $post, $secretlab;

	    if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
		    $sl_s_r = isset( $secretlab['show_read_more'] ) ? $secretlab['show_read_more'] : '1';
		    if ( '1' === $sl_s_r ) {
			    if ( ! empty( $secretlab['read_more_text'] ) ) {
				    echo '<a href="', get_the_permalink( $post ), '" rel="bookmark" class="more">', esc_html( $secretlab['read_more_text'] ), '</a>';
			    }
		    }
	    } else {
		    echo '<a href="' , get_the_permalink( $post ) , '" rel="bookmark" class="more">' , esc_html__( 'Read more', 'addys' ) , '</a>';
	    }
    }

    /**
     * Print HTML with meta information for current post: categories, comments counter, author, and date.
     *
     * Create your own entry_meta() to override in a child theme.
     *
    */
    public static function entry_meta_header() {
        global $secretlab;

        // Post author
        if ( isset( $secretlab['show_post_author'] ) ) {
            if ( '0' !=$secretlab['show_post_author'] ) {
                if ( 'post' === get_post_type() ) {
	                $post_id = get_queried_object_id();
	                $post_author_id = get_post_field( 'post_author', $post_id );
	                $anick = get_the_author_meta('nickname', $post_author_id);

	                $author_url = get_author_posts_url( $post_author_id, $anick );
	                echo '<span class="author vcard"><i></i> <a class="url fn n" href="'.esc_url( $author_url ).'" title="'.esc_attr__('View all posts by', 'addys').' '.$anick.'" rel="author">'.$anick.'</a></span>';
                }
            }
        } else {
	        if ( 'post' === get_post_type() ) {
		        $post_id = get_queried_object_id();
		        $post_author_id = get_post_field( 'post_author', $post_id );
		        $anick = get_the_author_meta('nickname', $post_author_id);

		        $author_url = get_author_posts_url( $post_author_id, $anick );
		        echo '<span class="author vcard"><i></i> <a class="url fn n" href="'.esc_url( $author_url ).'" title="'.esc_attr__('View all posts by', 'addys').' '.$anick.'" rel="author">'.$anick.'</a></span>';
	        }
        }

        //Post data
	    echo '<span class="updated"> ', get_the_modified_time( 'F jS, Y h:i a' ) , '</span>';
        if ( isset( $secretlab['show_post_date'] ) ) {
            if ( '0' !=$secretlab['show_post_date'] ) {
                echo '<span class="date"><i></i> ' , get_the_date() , '</span>';
            }
        } else {
            echo '<span class="date"><i></i> ' , get_the_date() , '</span>';
        }




        // Comments counter
        if ( isset( $secretlab['show_comments_count'] ) ) {
            if ( '0' !=$secretlab['show_comments_count'] ) {
                if ( comments_open( get_the_ID() ) ) {
                    echo '<span class="comments-link"><i></i> ';
                    comments_popup_link( esc_attr__( 'Add a comment', 'addys' ), esc_attr__( '1 Comment', 'addys' ), esc_html__( '% Comments', 'addys' ) );
                    echo '</span>';
                }
            }
        } else {
            echo '<span class="comments-link"><i></i> ';
            comments_popup_link( esc_attr__( 'Add a comment', 'addys' ), esc_attr__( '1 Comment', 'addys' ), esc_html__( '% Comments', 'addys' ) );
            echo '</span>';
        }
    }
    public static function entry_meta() {
        global $secretlab, $post;

        // Post author
        if ( isset( $secretlab['show_post_author'] ) ) {
            if ( '0' !=$secretlab['show_post_author'] ) {
                if ( 'post' === get_post_type() ) {

                    echo '<span class="author vcard"><i></i> <a class="url fn n" href="'.esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ).'" title="'.esc_attr__('View all posts by', 'addys').get_the_author().'" rel="author">'.get_the_author().'</a></span>';
                }
            }
        } else {

        }

        //Post data
	    echo '<span class="updated"> ', get_the_modified_time( 'F jS, Y h:i a' ) , '</span>';
        if ( isset( $secretlab['show_post_date'] ) ) {
            if ( '0' !=$secretlab['show_post_date'] ) {
                echo '<span class="date"><i></i> ' , get_the_date() , '</span>';
            }
        } else {
            echo '<span class="date"><i></i> ' , get_the_date() , '</span>';
        }




        // Comments counter
        if ( isset( $secretlab['show_comments_count'] ) ) {
            if ( '0' !=$secretlab['show_comments_count'] ) {
                if ( comments_open( get_the_ID() ) ) {
                    echo '<span class="comments-link"><i></i> ';
                    comments_popup_link( esc_attr__( 'Add a comment', 'addys' ), esc_attr__( '1 Comment', 'addys' ), esc_html__( '% Comments', 'addys' ) );
                    echo '</span>';
                }
            }
        } else {
            echo '<span class="comments-link"><i></i> ';
            comments_popup_link( esc_attr__( 'Add a comment', 'addys' ), esc_attr__( '1 Comment', 'addys' ), esc_html__( '% Comments', 'addys' ) );
            echo '</span>';
        }
    }

    /**
     * Display navigation to next/previous post when applicable.
     *
    */
    public static function post_nav() {
        global $post;

        // Don't print empty markup if there's nowhere to navigate.
        $previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
        $next = get_adjacent_post( false, '', false );

        if ( !$next && !$previous )
            return;
        ?>
        <nav class="nav-links clearfix" role="navigation">


            <div class="nav-previous"><?php previous_post_link( '%link', '<i class="nat-arrow-left8"></i> %title' ); ?></div>
            <div class="nav-next"><?php next_post_link( '%link', '%title <i class="nat-arrow-right8"></i>' ); ?></div>


        </nav><!-- .nav-links -->
        <?php
    }

    /* Prev & Next Post Narrow Icons */
    /**
     * Display navigation to next/previous post when applicable.
     *
     */
    public function post_navicon() {
        global $post;

        // Don't print empty markup if there's nowhere to navigate.
        $iprevious = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
        $inext = get_adjacent_post( false, '', false );

        if ( !$inext && !$iprevious )
            return;
        ?>
        <div class="post-navigation-icon" role="navigation">
            <?php next_post_link( '%link', '<span class="icon-arrow-left22"></span>', true ); ?>
            <?php previous_post_link( '%link', '<span class="icon-arrow-right22"></span>', true ); ?>
        </div>
        <?php
    }

    // Display of CSS class, for column option of tag, category, archive and index page
    public static function number_of_columns() {
        global $secretlab;
        if ( isset( $secretlab['blog-sidebar-layout'] ) ) {
            $sl_blog_sidebars = $secretlab['blog-sidebar-layout'];
            if ( ! is_single() ) {
                if ( '3' === $sl_blog_sidebars || '4' === $sl_blog_sidebars ) {
                    echo ' onecolumnnsb';
                } elseif ( '2' === $sl_blog_sidebars ) {
                    echo ' onecolumnsbs';
                } elseif ( '1' === $sl_blog_sidebars ) {
                    echo ' onecolumn';
                }
            }
        }
    }

	// Select Thumb Size depends on post caategory wide
	public static function thumb_size() {
		global $secretlab;
		if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
			$sl_blog_sidebars = $secretlab['blog-sidebar-layout'];
			if ( ! is_single() ) {
				if (  '2' === $sl_blog_sidebars || '1' === $sl_blog_sidebars ) {
					echo get_the_post_thumbnail( '', 'atiframebuilder_rectangle' );
				} elseif ( '3' === $sl_blog_sidebars || '4' === $sl_blog_sidebars) {
					echo get_the_post_thumbnail( '', 'atiframebuilder_rectangle_big' );
				}
			}
		} else {
			echo get_the_post_thumbnail();
        }
	}

    // Tags for blog post
    public static function tags() {
        global $secretlab;

        //tags
        if ( isset( $secretlab['show_post_tags'] ) ) {
            if ( '1' === $secretlab['show_post_tags'] ) {
                $tag_list = get_the_tag_list( '', ' ' );
                if ( $tag_list ) {
                    echo '<span class="tags-links"><b>' , esc_attr__( 'Tags', 'addys' ) , ':</b> ' , $tag_list , '</span>';
                }
            }
        } else {
            $tag_list = get_the_tag_list( '', ' ' );
            if ( $tag_list ) {
                echo '<span class="tags-links"><b>' , esc_attr__('Tags', 'addys' ) , ':</b> ' , $tag_list , '</span>';
            }
        }

    }

    // Comment layout
	public static function comment( $comment, $args, $depth ) {
        $c = $GLOBALS['comment'];
        $GLOBALS['comment'] = $comment;
        echo '<li ';
        comment_class();
        echo ' ' , 'id="li-comment-';
        comment_ID();
        echo '">';
        echo '<div id="comment-';
        comment_ID();
        echo '">';
        echo '<div class="comment-author vcard">' , get_avatar( $comment, $args['avatar_size'] ) , '</div>';
        if ( '0' === $comment->comment_approved ) {
            echo '<em>' , esc_attr__( 'Your comment is awaiting moderation.', 'addys' ) , '</em><br />';
        }
        echo '<footer class="comment-meta">';
        echo '<div class="comment-metadata">';
        echo '<span class="fn"> '.get_comment_author_link().'</span> <span class="date"><i></i> <a href="'.get_comment_link().'">'.get_comment_date().' '.esc_attr__( 'at', 'addys' ).' '.get_comment_time().'</a></span> ';
		echo '<span class="reply">';
		comment_reply_link(array_merge( $args, array( 'reply_text' => ''.esc_html__("Reply", 'addys'), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) );
		echo '</span>';
		edit_post_link( esc_html__( 'Edit', 'addys' ), '<span class="edit-link"><i></i> ', '</span>' );

        echo '</div>
        </footer>';
        echo '<div class="comment-content">';
        comment_text();

        echo '</div>';
        echo '
    </div>';
        $GLOBALS['comment'] = $c;
    }

    // Comment form fields update: add placeholders
    public function update_comments_fields( $fields ) {

        $commenter = wp_get_current_commenter();
        $req       = get_option( 'require_name_email' );
        $label     = $req ? '*' : ' ' . esc_attr__( '(optional)', 'addys' );
        $aria_req  = $req ? "aria-required='true'" : '';

        $fields['author'] =
            '<p class="comment-form-author">
                <label for="author">' . esc_attr__( "Name", 'addys' ) . $label . '</label>
                <input id="author" name="author" type="text" placeholder="' . esc_attr__( "Your Name", 'addys' ) . '" value="' . esc_attr( $commenter['comment_author'] ) .
            '" size="30" ' . $aria_req . ' />
            </p>';

        $fields['email'] =
            '<p class="comment-form-email">
                <label for="email">' . esc_attr__( "Email", 'addys' ) . $label . '</label>
                <input id="email" name="email" type="email" placeholder="' . esc_attr__( "Your E-mail", 'addys' ) . '" value="' . esc_attr( $commenter['comment_author_email'] ) .
            '" size="30" ' . $aria_req . ' />
            </p>';

        $fields['url'] =
            '<p class="comment-form-url">
                <label for="url">' . esc_attr__( "Website", 'addys' ) . '</label>
                <input id="url" name="url" type="url"  placeholder="' . esc_attr__( "Your Website", 'addys' ) . '" value="' . esc_attr( $commenter['comment_author_url'] ) .
            '" size="30" />
                </p>';

        return $fields;
    }

    public function update_comment_field( $fields ) {

        $fields['comment_field'] = str_replace(
            '<textarea',
            '<textarea placeholder="' . esc_attr__( 'Enter comment here...', 'addys' ) . '"',
            $fields['comment_field']
        );


        return $fields;
    }

}

?>
