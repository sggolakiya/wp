<?php
/**
 * The class contain functions for footer sections.
 */
class Secret_Lab_Footer {

    private static $footer_widget;

    /**
     * Atiframebuilder_Footer constructor.
     */
    public function __construct() {

        add_action( 'wp_enqueue_scripts', array( 'Secret_Lab_Footer', 'set_footer_widget' ), 10000 );
        
	    add_action( 'secretlab_theme_footer_set_footer_sidebar_layout', array( 'Secret_Lab_Footer', 'set_footer_sidebar_layout' ) );

		add_action( 'secretlab_theme_footer_footer', array( 'Secret_Lab_Footer', 'footer' ) );

		add_action( 'secretlab_theme_footer_footer_close_boxed_layout', array( 'Secret_Lab_Footer', 'footer_close_boxed_layout' ) );

	}

	public static function set_footer_sidebar_layout() {

        global $secretlab, $secretlab_layout;

        $sl_sidebar_layout = isset( $secretlab_layout[ $secretlab['secretlab_pagetype_prefix'] . 'sidebar-layout' ] ) ? $secretlab_layout[ $secretlab ['secretlab_pagetype_prefix'] . 'sidebar-layout' ] : '1';

        if ( '2' === $sl_sidebar_layout || '4' === $sl_sidebar_layout ) {
            echo '
<div class="col-lg-3 col-md-3 col-sm-12 widget-area right_sb animated slideInRight"><div>
';
	        $prefix = ( '' === $secretlab['secretlab_page_type'] ) ? '' : '_';
            if ( isset( $secretlab_layout[ $secretlab['secretlab_page_type'] . $prefix . 'right_sidebar_widgets' ] ) ) {
                if ( is_active_sidebar( $secretlab_layout[$secretlab['secretlab_page_type'] . $prefix . 'right_sidebar_widgets'] ) ) {
                    dynamic_sidebar($secretlab_layout[$secretlab['secretlab_page_type'] . $prefix . 'right_sidebar_widgets']);
                }
            } else {
                if ( is_active_sidebar( $secretlab['secretlab_page_type'] . '_default_right_sidebar' ) ) {
                    dynamic_sidebar( $secretlab['secretlab_page_type'] . '_default_right_sidebar' );
                }
            }
            echo '</div></div>';
        }
        if ( $sl_sidebar_layout !== '1' ) {
            echo '</div><!-- mainsidebar -->';
        }
    }

    public static function footer_close_boxed_layout() {
        global $secretlab, $secretlab_layout;
        if ( isset( $secretlab_layout[ $secretlab['secretlab_design_layout'] ] ) ) {
            if ( '2' === $secretlab_layout[ $secretlab['secretlab_design_layout'] ] ) {
                echo '</div></div></div>';
            }
        }
    }

    public static function set_footer_widget() {
        global $secretlab, $secretlab_layout;
        if ( isset( $secretlab['footer_widget'] ) && class_exists( 'custom_post_widget' ) ) {
            $prefix = ( '' === $secretlab['secretlab_page_type'] ) ? '' : '_';
            $secretlab[ $secretlab['secretlab_page_type'] . $prefix . 'footer_widget' ]        = empty( $secretlab [ $secretlab['secretlab_page_type'] . $prefix . 'footer_widget' ] ) ? $secretlab['footer_widget'] : $secretlab [ $secretlab ['secretlab_page_type'] . $prefix . 'footer_widget' ];
            $secretlab_layout[ $secretlab['secretlab_page_type'] . $prefix . 'footer_widget' ] = empty( $secretlab_layout [ $secretlab['secretlab_page_type'] . $prefix . 'footer_widget' ] ) ? $secretlab [ $secretlab['secretlab_page_type'] . $prefix . 'footer_widget' ] : $secretlab_layout[ $secretlab['secretlab_page_type'] . $prefix . 'footer_widget' ];
            if ( '-1' !== $secretlab_layout[ $secretlab['secretlab_page_type'] . $prefix . 'footer_widget' ] ) {
                ob_start();
                the_widget(
                    'custom_post_widget',
                    array(
                        'custom_post_id'        => $secretlab_layout[ $secretlab['secretlab_page_type'] . $prefix . 'footer_widget' ],
                        'apply_content_filters' => true,
                    ),
                    array(
                        'before_widget' => '<div class="footer-widget %s">',
                    )
                );
                $footer = apply_filters( 'secretlab_custom_footer', ob_get_contents() );
                ob_end_clean();
                preg_match_all( '~<style[\s\r\n].*?>(?P<styles>.*)\<\/style>~', $footer, $styles );
                if ( ! empty( $styles['styles'] ) ) {
                    if( is_array( $styles['styles'] ) ) {
                        foreach ( $styles['styles'] as $style ) {
                            wp_add_inline_style( 'secretlab-ownstyles', $style );
                        }
                    } else {
                        wp_add_inline_style( 'secretlab-ownstyles', $styles['styles'] );
                    }
                    self::$footer_widget = preg_replace( '@<(script|style)[^>]*?>.*?</\\1>@si', '', $footer );
                } else {
                    self::$footer_widget = $footer;
                }
            }
        }
    }

	/**
	 * Footer
	 */
	public static function footer() {
        if ( ! empty( self::$footer_widget ) ) {
            printf( '%s', self::$footer_widget );
        } else {
            // If theme without plugins
            echo '<div class="footer_alt"><div class="container">&copy; ' , esc_html( date( 'Y' ) ) , '</div></div>';
        }
    }
}

?>
