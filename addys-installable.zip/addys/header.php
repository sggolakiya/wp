<?php

/**
 * The Header template for our theme
 */

do_action( 'secretlab_theme_helpers_set_globals' );

?>
<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="format-detection" content="telephone=no">
	
	<?php

    wp_site_icon();
    do_action( 'secretlab_header_scripts' );

    do_action( 'secretlab_theme_header_set_boxed_background' );

    wp_head();

	?>
	
</head>

<body <?php body_class(); ?>>

<?php
wp_body_open ();
do_action( 'secretlab_theme_header_pageloader' );
do_action( 'secretlab_theme_header_set_boxed_layout' );
?>
<!-- HEADER START -->
<div class="headline">
	<?php
    do_action( 'secretlab_theme_header_header_layout' );
	?>
</div>
<!-- HEADER END -->

<main <?php do_action( 'secretlab_theme_layout_main_tag_classes' ); ?>>
    <?php
    do_action( 'secretlab_theme_header_set_header_sidebar_layout' );
    ?>