
<?php
/**
 * The template for displaying content
 * Used for both single and index/archive/search.
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <?php
    // CAGETORY page
    if ( ! is_single() && ! is_search() ) { ?>

        <?php if ( has_post_thumbnail() && ! is_attachment() ) {
            echo '<div class="thumb">';
		    do_action( 'secretlab_theme_blog_thumb' );
		    do_action( 'secretlab_theme_blog_cat_list' );
		    echo '<div><a href="'.get_the_permalink().'" rel="bookmark"><img src="' . esc_url( get_template_directory_uri() ) . '/images/eye.svg" alt="'.esc_attr__( 'Full Post', 'addys' ).'"></a></div></div>';
        }
        ?>
    <div class="c_block">
        <header class="entry-header">
            <h3 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
            <div class="entry-meta">
                <?php do_action( 'secretlab_theme_blog_entry_meta' ); ?>
            </div>
        </header><!-- .entry-header -->
        <div class="entry-content">
            <?php
            the_excerpt();
            do_action( 'secretlab_theme_blog_read_more' );
            ?>
        </div>
    </div>


    <?php } elseif ( is_single() ) {
        // SINGLE
        ?>
        <div class="postbody">
            <?php
            do_action( 'secretlab_theme_header_single_post_heading' );
            if ( has_post_thumbnail() && ! is_attachment() ) {
                echo '<div class="entry-thumbnail">';

                the_post_thumbnail( 'atiframebuilder_long' );

                echo '</div>';
            }
            ?>

        <div class="entry-content">
            <?php
            /* translators: %s: Name of current post */
            the_content(
                sprintf(
                    esc_attr__( 'Continue reading ', 'addys' ), '<span class="meta-nav">&rarr;</span>',
                    the_title( '<span class="screen-reader-text">', '</span>', false )
                )
            );


            wp_link_pages(
                array(
                    'before'      => '<div class="page-links"><span class="page-links-title">' . esc_attr__( 'Pages:', 'addys' ) . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>'
                )
            );
            do_action( 'secretlab_theme_blog_tags' );
            ?>
        </div>
        </div>
    <?php } elseif ( ! is_single() && is_search() ) { // Only display Excerpts for Search ?>
        <div class="c_block">
            <header class="entry-header">
	            <?php do_action( 'secretlab_theme_blog_cat_list' ); ?>
                <h3 class="entry-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
                <div class="entry-meta">
				    <?php do_action( 'secretlab_theme_blog_entry_meta' ); ?>
                </div>
            </header><!-- .entry-header -->
            <div class="entry-content">
			    <?php
			    the_excerpt();
			    do_action( 'secretlab_theme_blog_read_more' );
			    ?>
            </div>
        </div>
        <?php } ?>
</article><!-- #post -->

