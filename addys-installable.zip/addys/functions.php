<?php
/**
 *  Author: SecretLab
 *  URL: http://secretlab.pw
 *  Custom functions, support and more.
 **/

class Atiframe_Addys {

	/**
	 * @var Secret_Lab_Config
	 */
	public $config;

	public $welcome;

	private $installer;

	private $opt_name;

	public $blog;

	public $helpers;

	public $header;

	public $layout;

	public $woocommerce;

	public $footer;

	private $plugins;

	private static $instance;

	/**
	 * gets the instance via lazy initialization (created on first usage)
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	public function __construct() {
		if ( !class_exists( 'ReduxFrameworkPlugin' ) ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'save_styles' ) );
		}
		if ( !class_exists( 'KingComposer' ) ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'save_css' ) );
		}

		$this->opt_name = 'secretlab';

		if ( class_exists( 'Redux' ) && file_exists( get_template_directory() . '/inc/class-config.php' ) && ! class_exists( 'Secret_Lab_Config' ) ) {
			require get_template_directory() . '/inc/class-config.php';
			$this->config = new Secret_Lab_Config( $this->opt_name );
		}

		add_action( 'after_setup_theme', array( $this, 'theme_setup' ), 0 );

		$funct_path = get_template_directory() . '/functions/';

		require $funct_path . 'class-blog.php'; // Functions and layouts for blog
		require $funct_path . 'class-helpers.php'; // General Functions of the theme. Under the hood.
		require $funct_path . 'class-header.php'; // Functions for header section
		require $funct_path . 'class-layout.php'; // General Functions of the theme. Under the hood.
		require $funct_path . 'class-woocommerce.php'; // Functions for woocommerce and a cart in menu
		require $funct_path . 'class-footer.php'; // Functions for footer section

		// Load all core theme classes
		$this->blog        = new Secret_Lab_Blog();
		$this->helpers     = new Secret_Lab_Helpers( $this->opt_name );
		$this->header      = new Secret_Lab_Header();
		$this->layout      = new Secret_Lab_Layout();
		$this->woocommerce = new Secret_Lab_Woocommerce();
		$this->footer      = new Secret_Lab_Footer();

		/**
		 * SecretLab only works in WordPress 4.1 or later.
		 */
		if ( version_compare( $GLOBALS['wp_version'], '4.1-alpha', '<' ) ) {
			require get_template_directory() . '/inc/class-back-compat.php';

			add_action( 'after_switch_theme', array( 'Secret_Lab_Back_Compat', 'switch_theme' ) );

			add_action( 'load-customize.php', array( 'Secret_Lab_Back_Compat', 'customize' ) );

			add_action( 'template_redirect', array( 'Secret_Lab_Back_Compat', 'preview' ) );
		}

		/** Admin only actions **/
		if ( is_admin() ) {

			// Welcome Page section
			if ( class_exists( 'SECL_Installer' ) ) {

				$this->installer = new SECL_Installer();
				add_action( 'admin_menu', array( $this, 'welcome_screen_page' ) );
				add_action( 'admin_menu', array( $this, 'documentation_screen_page' ) );

			}

			delete_transient( '_redux_activation_redirect' );
			delete_transient( '_wc_activation_redirect' );
			$GLOBALS['redux_notice_check'] = 0;
			update_option( 'revslider-valid-notice', 'false' );
			add_filter( 'wpcf7_autop_or_not', '__return_false' );

			add_filter( 'yikes_easy_mailchimp_extender_use_custom_db', array( $this, 'del_red_mailchamp' ) );

			add_action( 'redux/page/secretlab/form/before', array( $this, 'save_installed' ) );

			require get_template_directory() . '/inc/class-tgm-plugin-activation.php';

			

			$this->set_plugins();

			add_action( 'admin_init', array( $this, 'add_kingcomposer_actions' ) );

		} else {

			add_action( 'comment_form', array( $this, 'comment_checkbox' ) );

			add_action( 'pre_comment_on_post', array( $this, 'comment_check' ) );

		}

		add_action( 'widgets_init', array( $this, 'widgets_init' ) );

		// This theme uses its own gallery styles.
		add_filter( 'use_default_gallery_style', '__return_false' );

		/* Fixes quotes in row_inner */
		add_filter( 'no_texturize_shortcodes', array( $this, 'filter_kc_row_inner' ), 10, 1 );


	}

	/**
	 * Theme setup.
	 *
	 * Sets up theme defaults and registers the various WordPress features that
	 * Theme supports.
	 *
	 * @uses load_theme_textdomain() For translation/localization support.
	 * @uses add_editor_style() To add Visual Editor stylesheets.
	 * @uses add_theme_support() To add support for automatic feed links, post
	 * formats, and post thumbnails.
	 * @uses register_nav_menu() To add support for a navigation menu.
	 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
	 */
	public function theme_setup() {

		/**
		 * Makes The SEO available for translation.
		 * Translations can be added to the /languages/ directory.
		 * If you're building a theme based on SecretLab, use a find and
		 * replace to change 'addys' to the name of your theme in all
		 * template files.
		 */
		load_theme_textdomain( 'addys', get_template_directory() . '/languages' );

		/**
		 * This theme styles the visual editor to resemble the theme style,
		 * specifically font, colors, icons, and column width.
		 */
		add_editor_style( array( 'css/editor-style.css', 'genericons/genericons.css' ) );

		// Adds RSS feed links to <head> for posts and comments.
		add_theme_support( 'automatic-feed-links' );

		/**
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/**
		 * Switches default core markup for search form, comment form,
		 * and comments to output valid HTML5.
		 */
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menu( 'secretlab_top_menu', esc_attr__( 'Header Menu', 'addys' ) );

		/*
		* This theme uses a custom image size for featured images, displayed on
		* "standard" posts and pages.
		*/
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 600, 725, true );
		add_image_size( 'atiframebuilder_portfolio', 1170, 9999, true );
		add_image_size( 'atiframebuilder_masonry600', 600, 9999, true );
		add_image_size( 'atiframebuilder_thumb', 600, 600, true );
		add_image_size( 'atiframebuilder_thumb_300', 300, 300, true );
		add_image_size( 'atiframebuilder_long', 1170, 475, true );
		add_image_size( 'atiframebuilder_rectangle', 600, 400, true );
		add_image_size( 'atiframebuilder_rectangle_big', 900, 450, true );
		add_image_size( 'atiframebuilder_masonry', 500, 800, true );
		add_image_size( 'atiframebuilder_longhalf', 585, 270, true );

	}

	/**
	 * Register 7 widget areas.
	 */
	public function widgets_init() {

		register_sidebar(
			array(
				'name'          => esc_html__( 'Left Sidebar', 'addys' ),
				'id'            => '_default_left_sidebar',
				'description'   => esc_html__( 'Appears in the left section of the site.', 'addys' ),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget'  => '</aside>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Right Sidebar', 'addys' ),
				'id'            => '_default_right_sidebar',
				'description'   => esc_html__( 'Appears in the right section of the site.', 'addys' ),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget'  => '</aside>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Left Blog Sidebar', 'addys' ),
				'id'            => 'blog_default_left_sidebar',
				'description'   => esc_html__( 'Appears in the left blog section of the site.', 'addys' ),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget'  => '</aside>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Right Blog Sidebar', 'addys' ),
				'id'            => 'blog_default_right_sidebar',
				'description'   => esc_html__( 'Appears in the right blog section of the site.', 'addys' ),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget'  => '</aside>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Left Shop Sidebar', 'addys' ),
				'id'            => 'shop_default_left_sidebar',
				'description'   => esc_html__( 'Appears in the left shop section of the site.', 'addys' ),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget'  => '</aside>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			)
		);
		register_sidebar(
			array(
				'name'          => esc_html__( 'Right Shop Sidebar', 'addys' ),
				'id'            => 'shop_default_right_sidebar',
				'description'   => esc_html__( 'Appears in the left shop section of the site.', 'addys' ),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget'  => '</aside>',
				'before_title'  => '<h3 class="widget-title">',
				'after_title'   => '</h3>',
			)
		);

	}


	public function del_red_mailchamp( $custom_db ) {
		update_option( 'yikes_mailchimp_activation_redirect', 'false' );

		return $custom_db;
	}

	public function save_installed() {
		if ( ! empty( $_GET['atifrom'] ) && 'welcome' === $_GET['atifrom'] ) {
			echo '<div class="updated notice my-acf-notice is-dismissible"><p>' . esc_attr__( 'SecretLab themes data was installed successfully',
					'addys' ) . '</p></div>';
		}
	}

	public function comment_checkbox() {
		echo '<p class="comment-form-ch"><input id="secretlab_ch" name="secretlab_ch" type="checkbox" /></p>';
	}

	public function comment_check( $comment_data ) {
		if ( isset( $_POST['secretlab_ch'] ) ) {
			wp_die( esc_html__( 'Error: please, do not set hidden field', 'addys' ) );
		} else {
			return $comment_data;
		}
	}

	public function installer() {
		return $this->installer;
	}

	public function blog() {
		return $this->blog;
	}

	public function helpers() {
		return $this->helpers;
	}

	public function header() {
		return $this->header;
	}

	public function layout() {
		return $this->layout;
	}

	public function woocommerce() {
		return $this->woocommerce;
	}

	public function footer() {
		return $this->footer;
	}

	public function set_plugins() {
		// Change plugins list if inctaller is active
		if ( class_exists( 'SECL_Installer' ) ) {
			require get_template_directory() . '/inc/class-plugins-list.php';
			$this->plugins = new Secret_Lab_Plugins();
		} else {
			require get_template_directory() . '/inc/class-plugins-list_f.php';
			$this->plugins = new Secret_Lab_Plugins_F();
		}
	}

	public function plugins() {
		return $this->plugins;
	}

	public function welcome_screen_page() {
		if ( isset( $this->installer ) ) {
			add_theme_page( esc_attr__( 'SecretLab', 'addys' ),
				esc_attr__( 'SecretLab', 'addys' ),
				'read',
				'welcome',
				array( $this, 'welcome_page' ) );
		}
	}

	public function documentation_screen_page() {
		if ( isset( $this->installer ) ) {
			add_theme_page(
				esc_attr__( 'Documentation', 'addys' ),
				esc_attr__( 'Documentation', 'addys' ),
				'read',
				'welcomedocs',
				array( $this, 'welcome_docs' ) );
		}
	}

	public function welcome_page() {

		require get_template_directory() . '/inc/class-welcome-page.php';

		$this->welcome = new Secret_Lab_Welcome();

		$this->welcome->render();

	}

	public function welcome_docs() {

		require get_template_directory() . '/inc/class-welcome-docs.php';

		$this->welcome = new Secret_Lab_Docs();

		$this->welcome->render();

	}

	public function filter_kc_row_inner( $default_no_texturize_shortcodes ) {
		$default_no_texturize_shortcodes[] = 'kc_row_inner';

		return $default_no_texturize_shortcodes;
	}

	public function sliders_message() {
		$sliders = array(
			'LS_Sliders',
			'RevSliderSlider',
			'SmartSlider3',
		);
		$c       = 0;

		foreach ( $sliders as $slider ) {
			if ( class_exists( $slider ) ) {
				$c ++;
			}
		}

		if ( 1 < $c ) {
			echo '<div id="message" class="notice notice-warning is-dismissible">';
			echo '<p>' . esc_html__( 'You use more that one slider on the site, so we advise to you leave only one of them. You can deactiveta others at:',
					'addys' ) . '</p>';
			echo '<a class="meta_btn" href="' . get_admin_url( null, 'plugins.php' ) . '">' . esc_html__( 'plugins',
					'addys' ) . '</a>';
			echo '
    </div>';
		} else {
			echo '';
		}
	}



	public function add_kingcomposer_actions() {
		if ( class_exists( 'KingComposer' ) ) {
			add_action( 'save_post', array( $this, 'save_post_thumbnail' ), 1000, 2 );
			add_filter( 'kc_before_instant_save', array( $this, 'save_live_editor_revision' ), 10, 2 );
		}
	}

	public function save_post_thumbnail( $post_id, $post ) {
		if (!current_user_can('publish_pages')) {
			return;
		}

		$id = isset($_POST['post_ID']) ? $_POST['post_ID'] : null;

		if( null == $id ){
			return;
		}

		$thumbnail = get_home_url().'/scrs/'.get_the_title().'.jpg';
		$param = (array)get_post_meta ($id, 'kc_data', true);

		if( empty( $param ) ){
			$param = array(
				'mode' => '',
				'css' => '',
				'max_width' => '',
				'classes' => '',
				'thumbnail' => $thumbnail,
				'collapsed' => '',
				'optimized' => ''
			);
		} else {
			if ( empty( $param['thumbnail'] ) ) {
				$param['thumbnail'] = $thumbnail;
			}
		}

		if (!add_post_meta( $id, 'kc_data', $param, true)) {
			update_post_meta( $id, 'kc_data', $param );
		}


	}

	public function save_live_editor_revision( $addition_check, $id ) {
		wp_save_post_revision( $id );
		return $addition_check;
	}

	public function save_styles() {
		wp_enqueue_style( 'save-fonts', 'https://fonts.googleapis.com/css?family=Josefin+Sans:400|Dosis:600,400&display=swap', array(), '1.0.0' );
		
	}

	public function save_css() {
		wp_enqueue_style( 'save-style', get_template_directory_uri() . '/css/save.css', array( 'secretlab-ownstyles' ));
		wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/css/font-awesome.min.css', array( 'secretlab-ownstyles' ));

	}
}

global $secretlab_theme;
$secretlab_theme = Atiframe_Addys::get_instance();
