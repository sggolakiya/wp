<?php
/**
 * The template for displaying the footer
 */
?>

</div> <!-- col6-12 -->
<?php
do_action( 'secretlab_theme_footer_set_footer_sidebar_layout' );
?>

<?php
do_action( 'secretlab_theme_helpers_modal' );
?>
</main>

<?php
do_action( 'secretlab_theme_footer_footer' );

do_action( 'secretlab_theme_layout_scroll_button' );
?>

<?php
do_action( 'secretlab_theme_footer_footer_close_boxed_layout' );
?>

<?php wp_footer(); ?>

</body>
</html>