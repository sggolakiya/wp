<?php

/** Theme Options Config File */

if ( ! class_exists( 'Redux' ) ) {
	return;
}

class Secret_Lab_Config {

	public $opt_name;

	public $scheme0;

	public $scheme1;

	public $scheme2;

	public $scheme3;

	public $scheme4;

	public $scheme5;

	public $theme;

	public $allowed_html;

	public $sample_patterns_path;

	public $sample_patterns_url;

	public $sample_patterns;

	public $args;

	public $secretlab;

	/**
	 * Secret_Lab_Config constructor.
	 */
	public function __construct( $opt_name ) {

		// This is your option name where all the Redux data is stored.
		$this->opt_name = $opt_name;

		// Colors Presets;
		$this->scheme0 = '{"pgl_color_bgr":{"color":"#000000","alpha":"0.95","rgba":"rgba(0,0,0,0.95)"},
                            "pgl_color":{"color":"#86af49","alpha":"1","rgba":"rgba(134,175,73,1)"},
                            "gc1":{"color":"#0081d7","alpha":"1","rgba":"rgba(0,129,215,1)"},
                            "gc1d":{"color":"#0062a3","alpha":"1","rgba":"rgba(0,98,163,1)"},
                            "link":{"regular":"#0081d7","hover":"#0062a3","active":"#0062a3"},
                            "gc2":{"color":"#f77924","alpha":"1","rgba":"rgba(247,121,36,1)"},
                            "gc2d":{"color":"#ef5229","alpha":"1","rgba":"rgba(239,82,41,1)"},
                            "bgrc":{"color":"#ffffff","alpha":"1","rgba":"rgba(255,255,255,1)"},
                            "ac1":{"color":"#5f7278","alpha":"1","rgba":"rgba(95,114,120,1)"},
                            "ac1l":{"color":"#8a9a9a","alpha":"1","rgba":"rgba(138,154,154,1)"},
                            "ac1d":{"color":"#202729","alpha":"1","rgba":"rgba(32,39,41,1)"}}';

		$this->scheme1 = '{"pgl_color_bgr":{"color":"#000000","alpha":"0.95","rgba":"rgba(0,0,0,0.95)"},
                            "pgl_color":{"color":"#86af49","alpha":"1","rgba":"rgba(134,175,73,1)"},
                            "gc1":{"color":"#0699b8","alpha":"1","rgba":"rgba(6,153,184,1)"},
                            "gc1d":{"color":"#06b2b8","alpha":"1","rgba":"rgba(6,178,184,1)"},
                            "link":{"regular":"#0699b8","hover":"#06b2b8","active":"#06b2b8"},
                            "gc2":{"color":"#86af49","alpha":"1","rgba":"rgba(134,175,73,1)"},
                            "gc2d":{"color":"#44883d","alpha":"1","rgba":"rgba(68,136,61,1)"},
                            "bgrc":{"color":"#ffffff","alpha":"1","rgba":"rgba(255,255,255,1)"},
                            "ac1":{"color":"#5f7278","alpha":"1","rgba":"rgba(95,114,120,1)"},
                            "ac1l":{"color":"#8a9a9a","alpha":"1","rgba":"rgba(138,154,154,1)"},
                            "ac1d":{"color":"#202729","alpha":"1","rgba":"rgba(32,39,41,1)"}}';

		$this->scheme2 = '{"pgl_color_bgr":{"color":"#000000","alpha":"0.95","rgba":"rgba(0,0,0,0.95)"},
                            "pgl_color":{"color":"#86af49","alpha":"1","rgba":"rgba(134,175,73,1)"},
                            "gc1":{"color":"#86af49","alpha":"1","rgba":"rgba(134,175,73,1)"},
                            "gc1d":{"color":"#44883d","alpha":"1","rgba":"rgba(68,136,61,1)"},
                            "link":{"regular":"#86af49","hover":"#44883d","active":"#44883d"},
                            "gc2":{"color":"#86af49","alpha":"1","rgba":"rgba(134,175,73,1)"},
                            "gc2d":{"color":"#44883d","alpha":"1","rgba":"rgba(68,136,61,1)"},
                            "bgrc":{"color":"#ffffff","alpha":"1","rgba":"rgba(255,255,255,1)"},
                            "ac1":{"color":"#5f7278","alpha":"1","rgba":"rgba(95,114,120,1)"},
                            "ac1l":{"color":"#8a9a9a","alpha":"1","rgba":"rgba(138,154,154,1)"},
                            "ac1d":{"color":"#202729","alpha":"1","rgba":"rgba(32,39,41,1)"}}';

		$this->scheme3 = '{"pgl_color_bgr":{"color":"#000000","alpha":"0.95","rgba":"rgba(0,0,0,0.95)"},
                            "pgl_color":{"color":"#ee9200","alpha":"1","rgba":"rgba(238,146,0,1)"},
                            "gc1":{"color":"#8358dc","alpha":"1","rgba":"rgba(131,88,220,1)"},
                            "gc1d":{"color":"#7900e0","alpha":"1","rgba":"rgba(121,0,224,1)"},
                            "link":{"regular":"#ee9200","hover":"#7900e0","active":"#7900e0"},
                            "gc2":{"color":"#ee9200","alpha":"1","rgba":"rgba(238,146,0,1)"},
                            "gc2d":{"color":"#ef5229","alpha":"1","rgba":"rgba(239,82,41,1)"},
                            "bgrc":{"color":"#ffffff","alpha":"1","rgba":"rgba(255,255,255,1)"},
                            "ac1":{"color":"#5f7278","alpha":"1","rgba":"rgba(95,114,120,1)"},
                            "ac1l":{"color":"#8a9a9a","alpha":"1","rgba":"rgba(138,154,154,1)"},
                            "ac1d":{"color":"#202729","alpha":"1","rgba":"rgba(32,39,41,1)"}}';

		$this->scheme4 = '{"pgl_color_bgr":{"color":"#000000","alpha":"0.95","rgba":"rgba(0,0,0,0.95)"},
                            "pgl_color":{"color":"#fde428","alpha":"1","rgba":"rgba(253,228,40,1)"},
                            "gc1":{"color":"#032e58","alpha":"1","rgba":"rgba(3,46,88,1)"},
                            "gc1d":{"color":"#032e58","alpha":"1","rgba":"rgba(3,46,88,1)"},
                            "link":{"regular":"#032e58","hover":"#032e58","active":"#032e58"},
                            "gc2":{"color":"#fde428","alpha":"1","rgba":"rgba(253,228,40,1)"},
                            "gc2d":{"color":"#fde428","alpha":"1","rgba":"rgba(253,228,40,1)"},
                            "bgrc":{"color":"#ffffff","alpha":"1","rgba":"rgba(255,255,255,1)"},
                            "ac1":{"color":"#5f7278","alpha":"1","rgba":"rgba(95,114,120,1)"},
                            "ac1l":{"color":"#8a9a9a","alpha":"1","rgba":"rgba(138,154,154,1)"},
                            "ac1d":{"color":"#202729","alpha":"1","rgba":"rgba(32,39,41,1)"}}';

		$this->scheme5 = '{"pgl_color_bgr":{"color":"#000000","alpha":"0.95","rgba":"rgba(0,0,0,0.95)"},
                            "pgl_color":{"color":"#cc181b","alpha":"1","rgba":"rgba(204,24,27,1)"},
                            "gc1":{"color":"#cc181b","alpha":"1","rgba":"rgba(204,24,27,1)"},"gc1d":{"color":"#cc181b","alpha":"1","rgba":"rgba(204,24,27,1)"},"link":{"regular":"#cc181b","hover":"#f77924","active":"#f77924"},"gc2":{"color":"#f77924","alpha":"1","rgba":"rgba(247,121,36,1)"},"gc2d":{"color":"#f77924","alpha":"1","rgba":"rgba(247,121,36,1)"},"bgrc":{"color":"#ffffff","alpha":"1","rgba":"rgba(255,255,255,1)"},"ac1":{"color":"#5f7278","alpha":"1","rgba":"rgba(95,114,120,1)"},"ac1l":{"color":"#8a9a9a","alpha":"1","rgba":"rgba(138,154,154,1)"},"ac1d":{"color":"#202729","alpha":"1","rgba":"rgba(32,39,41,1)"},"redux-backup":1}';

		// Allowed HTML tags for escaping of texts
		$this->allowed_html = array(
			'a'      => array(
				'href'   => array(),
				'title'  => array(),
				'target' => array(),
			),
			'br'     => array(),
			'em'     => array(),
			'strong' => array(),
			'h1'     => array(),
			'h2'     => array(),
			'h3'     => array(),
			'h4'     => array(),
			'h5'     => array(),
			'h6'     => array(),
			'p'      => array(
				'style' => array(),
			),
			'b'      => array(),
			'i'      => array(),
			'u'      => array(),
			'ol'     => array(),
			'ul'     => array(),
			'li'     => array(),
			'code'   => array(),
			'del'    => array(),
		);

		// Background Patterns Reader
		$this->sample_patterns_path = ReduxFramework::$_dir . '/patterns/';
		$this->sample_patterns_url  = ReduxFramework::$_url . '/patterns/';
		$this->sample_patterns      = array();

		if ( is_dir( $this->sample_patterns_path ) ) {

			if ( $this->sample_patterns_dir = opendir( $this->sample_patterns_path ) ) {
				$this->sample_patterns = array();

				while ( ( $this->sample_patterns_file = readdir( $this->sample_patterns_dir ) ) !== false ) {

					if ( stristr( $this->sample_patterns_file,
							'.png' ) !== false || stristr( $this->sample_patterns_file, '.jpg' ) !== false ) {
						$name                    = explode( '.', $this->sample_patterns_file );
						$name                    = str_replace( '.' . end( $name ), '', $this->sample_patterns_file );
						$this->sample_patterns[] = array(
							'alt' => $name,
							'img' => $this->sample_patterns_url . $this->sample_patterns_file,
						);
					}
				}
			}
		}

		/* ---> SET ARGUMENTS
		* All the possible arguments for Redux.
		* For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
		* */

		$this->theme = wp_get_theme(); // For use with some settings. Not necessary.

		$this->args = array(
			// TYPICAL -> Change these values as you need/desire
			'secretlab_theme_opt_name' => $this->opt_name,
			// This is where your data is stored in the database and also becomes your global variable name.
			'display_name'             => $this->theme->get( 'secretlab-theme' ),
			// Name that appears at the top of your panel
			'display_version'          => $this->theme->get( 'Version 1.0' ),
			// Version that appears at the top of your panel
			'menu_type'                => 'menu',
			//Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
			'allow_sub_menu'           => true,
			// Show the sections below the admin menu item or not
			'menu_title'               => esc_attr__( 'Theme Options', 'addys' ),
			'page_title'               => esc_attr__( 'SecretLab Theme Options', 'addys' ),
			// You will need to generate a Google API key to use this feature.
			// Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
			'google_api_key'           => Secret_Lab_Config::google_api(),
			// Set it you want google fonts to update weekly. A google_api_key value is required.
			'google_update_weekly'     => true,
			// Must be defined to add google fonts to the typography module
			'async_typography'         => true,
			// Use a asynchronous font on the front end or font string
			//'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
			'admin_bar'                => true,
			// Show the panel pages on the admin bar
			'admin_bar_icon'           => 'dashicons-portfolio',
			// Choose an icon for the admin bar menu
			'admin_bar_priority'       => 50,
			// Choose an priority for the admin bar menu
			'global_variable'          => 'secretlab',
			// Set a different name for your global variable other than the secretlab_theme_opt_name
			'dev_mode'                 => false,
			// Show the time the page took to load, etc
			'update_notice'            => true,
			// If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
			'customizer'               => true,
			// Enable basic customizer support
			//'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
			//'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

			// OPTIONAL -> Give you extra features
			'page_priority'            => null,
			// Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
			'page_parent'              => 'themes.php',
			// For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
			'page_permissions'         => 'manage_options',
			// Permissions needed to access the options panel.
			'menu_icon'                => '',
			// Specify a custom URL to an icon
			'last_tab'                 => '',
			// Force your panel to always open to a specific tab (by id)
			'page_icon'                => 'icon-themes',
			// Icon displayed in the admin panel next to your menu_title
			'page_slug'                => '_sl_theme_options',
			// Page slug used to denote the panel
			'save_defaults'            => true,
			// On load save the defaults to DB before user clicks save or not
			'default_show'             => false,
			// If true, shows the default value next to each field that is not the default value.
			'default_mark'             => '',
			// What to print by the field's title if the value shown is default. Suggested: *
			'show_import_export'       => true,
			// Shows the Import/Export panel when not used as a field.

			// CAREFUL -> These options are for advanced use only
			'transient_time'           => 60 * MINUTE_IN_SECONDS,
			'output'                   => true,
			// Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
			'output_tag'               => true,
			// Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
			'footer_credit'            => esc_attr__( 'Developed with love by www.SecretLab.pw', 'addys' ),
			// Disable the footer credit of Redux. Please leave if you can help it.

			// FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
			'database'                 => '',
			// possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

			'use_cdn' => true,
			// If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

			'compiler' => true,

			'disable_tracking' => true,

			// HINTS
			'hints'            => array(
				'icon'          => 'el el-question-sign',
				'icon_position' => 'right',
				'icon_color'    => 'lightgray',
				'icon_size'     => 'normal',
				'tip_style'     => array(
					'color'   => 'light',
					'shadow'  => true,
					'rounded' => false,
					'style'   => '',
				),
				'tip_position'  => array(
					'my' => 'top left',
					'at' => 'bottom right',
				),
				'tip_effect'    => array(
					'show' => array(
						'effect'   => 'slide',
						'duration' => '500',
						'event'    => 'mouseover',
					),
					'hide' => array(
						'effect'   => 'slide',
						'duration' => '500',
						'event'    => 'click mouseleave',
					),
				),
			),
		);

		// ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external links.
		$this->args['admin_bar_links'][] = array(
			'id'    => 'sl-docs',
			'href'  => 'http://secretlab.pw/documentation/',
			'title' => esc_attr__( 'Documentation', 'addys' ),
		);

		$this->args['admin_bar_links'][] = array(
			'id'    => 'sl-support',
			'href'  => 'https://support.secretlab.pw/',
			'title' => esc_attr__( 'Support', 'addys' ),
		);

		$this->args['admin_bar_links'][] = array(
			'id'    => 'sl-extensions',
			'href'  => 'http://secretlab.pw/',
			'title' => esc_attr__( 'SecretLab Website', 'addys' ),
		);


		// Add content after the form.
		$this->args['footer_text'] = '<p>' . esc_attr__( 'Support Panel: ',
				'addys' ) . '<a href="https://support.secretlab.pw/" target="_blank">https://support.secretlab.pw/</a></p>';

		Redux::setArgs( $this->opt_name, $this->args );


		/*
		 As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for
		*/

		// -> START General Settings Tab with no subsections
		Redux::setSection( $this->opt_name,
			array(
				'title'  => esc_attr__( 'General Setting', 'addys' ),
				'id'     => 'general',
				'icon'   => 'el el-home',
				'fields' => array(
					array(
						'id'       => 'homepage',
						'type'     => 'text',
						'class'    => 'hide',
						'readonly' => true,
						'default'  => get_option( 'page_on_front' ),
					),
					array(
						'id'       => 'google_api_key_opt',
						'type'     => 'text',
						'title'    => esc_attr__( 'Google API Key', 'addys' ),
						'subtitle' => esc_attr__( 'You can get a new API key at https://developers.google.com/maps/documentation/javascript/get-api-key',
							'addys' ),
						'default'  => '',
					),
					array(
						'id'       => 'contacts_email',
						'type'     => 'text',
						'title'    => esc_attr__( 'Email for Contact Form 7', 'addys' ),
						'subtitle' => esc_attr__( 'You can add a specific email address at each form',
							'addys' ),
						'default'  => '',
					),
					array(
						'id'       => 'sender_email',
						'type'     => 'text',
						'title'    => esc_attr__( 'Sender Email for Contact Form 7 Plugin', 'addys' ),
						'subtitle' => esc_attr__( 'You can add a specific email address at each form',
							'addys' ),
						'default'  => '',
					),
					array(
						'id'       => 'cases-info2',
						'type'     => 'info',
						'style'    => 'info',
						'title'    => esc_attr__( 'Select Homepage', 'addys' ),
						'subtitle' => esc_attr__( 'You should select you homepage and blogpage on ',
								'addys' ) . '<a href="/wp-admin/options-reading.php">/wp-admin/options-reading.php</a>',
					),
					array(
						'id'      => 'header_widget',
						'type'    => 'select',
						'title'   => esc_attr__( 'Select Header', 'addys' ),
						'options' => Secret_Lab_Config::get_composer_block_array( 'header' ),
						'default' => '1833',
					),

					array(
						'id'       => 'header_type',
						'type'     => 'select',
						'title'    => esc_attr__( 'Select Header type', 'addys' ),
						'options'  => array( 1 => 'Slider', ),
						'default'  => 1,
						'required' => array( 'header_type', '<', '0' ),
					),
					array(
						'id'       => 'pick_slider',
						'type'     => 'select',
						'title'    => esc_attr__( 'Select Slider', 'addys' ),
						'subtitle' => esc_attr__( 'Select slider for header section', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => Secret_Lab_Config::get_sliders_array(),
						'default'  => '0',
					),
					array(
						'id'      => 'footer_widget',
						'type'    => 'select',
						'title'   => esc_attr__( 'Select Footer', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options' => Secret_Lab_Config::get_composer_block_array( 'footer' ),

						'default' => '1848',
					),
					array(
						'id'      => 'scroll-to-top',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Display Scroll to Top Button?', 'addys' ),
						'default' => true,
					),


					array(
						'id'       => 'pageloader',
						'type'     => 'switch',
						'title'    => esc_attr__( 'Display Page Loader', 'addys' ),
						'subtitle' => esc_attr__( 'Do you want to show page loader, when website is loading?',
							'addys' ),
						'default'  => true,
						'indent'   => true,
					),

					array(
						'id'       => 'pgl_color_bgr',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Select Background Color for Page Loader', 'addys' ),
						'output'   => array( 'background-color' => '.loaderbgr' ),
						'default'  => array(
							'color' => '#000000',
							'alpha' => 0.95,
						),
						'required' => array( 'pageloader', '=', true ),
					),
					array(
						'id'    => 'pgl_color',
						'type'  => 'color_rgba',
						'title' => esc_attr__( 'Select Arrow Color for Page Loader', 'addys' ),

						'default'  => array(
							'color' => '#86af49',
							'alpha' => 1,
						),
						'required' => array( 'pageloader', '=', true ),
					),
				),
			) );

		/*
		 * <--- END SECTIONS
		 */


		// -> START Design Tab


		// Layout Design Tab
		Redux::setSection( $this->opt_name,
			array(
				'title'  => esc_attr__( 'Layout', 'addys' ),
				'id'     => 'design-layout-subsection',
				'icon'   => 'el el-th-large',
				'fields' => array(
					array(
						'id'       => 'single-header',
						'type'     => 'switch',
						'title'    => esc_attr__( 'Display Page H1 Heading', 'addys' ),
						'subtitle' => esc_attr__( 'Do you want to show H1 heading for pages? Usually we display it through drag&drop builder',
							'addys' ),
						'default'  => false,
						'indent'   => false,
					),
					array(
						'id'            => 'transition',
						'type'          => 'slider',
						'title'         => esc_attr__( 'Transition time', 'addys' ),
						'subtitle'      => esc_attr__( 'Select hover effects time in ms', 'addys' ),
						'desc'          => esc_attr__( 'Slider description. Min: 0, max: 1000, step: 5, default value: 600',
							'addys' ),
						'default'       => 400,
						'min'           => 0,
						'step'          => 5,
						'max'           => 1000,
						'display_value' => 'text',
					),

					array(
						'id'      => 'design-layout',
						'type'    => 'image_select',
						'title'   => esc_attr__( 'Select page layout', 'addys' ),

						//Must provide key => value(array:title|img) pairs for radio options
						'options' => array(
							'1' => array(
								'alt' => 'Full width layout',
								'img' => get_template_directory_uri() . '/images/framework/full.gif',
							),
							'2' => array(
								'alt' => 'Boxed layout, maximum resolution - 1170 px',
								'img' => get_template_directory_uri() . '/images/framework/boxed.gif',
							),
						),
						'default' => '1',
					),
					array(
						'id'       => 'boxed-background',
						'type'     => 'background',
						'title'    => esc_attr__( 'Background settings for box', 'addys' ),
						'output'   => array( '.page .mainbgr', ),
						'default'  => array(
							'background-color'      => '#323232',
							'background-repeat'     => 'no-repeat',
							'background-attachment' => 'fixed',
							'background-position'   => 'center center',
							'background-size'       => 'inherit',
						),
						'required' => array( 'design-layout', '=', '2' ),
					),

					array(
						'id'      => 'content-background',
						'type'    => 'background',
						'title'   => esc_attr__( 'Background settings for content section', 'addys' ),
						'output'  => array( '.page main', ),
						'default' => array(
							'background-color'      => '#ffffff',
							'background-repeat'     => 'no-repeat',
							'background-attachment' => 'fixed',
							'background-position'   => 'center center',
							'background-size'       => 'inherit',
							'background-image'      => '',
						),

					),
					array(
						'id'          => 'sidebar-layout',
						'type'        => 'image_select',
						'title'       => esc_attr__( 'Select sidebar option', 'addys' ),
						'description' => esc_attr__( 'Default sidebars is Left Sidebar and Right sidebar',
							'addys' ),

						//Must provide key => value(array:title|img) pairs for radio options
						'options'     => array(
							'1' => array(
								'alt' => 'Without sidebar',
								'img' => get_template_directory_uri() . '/images/framework/nosidebar.gif',
							),
							'2' => array(
								'alt' => '2 sidebars',
								'img' => get_template_directory_uri() . '/images/framework/2sidebars.gif',
							),
							'3' => array(
								'alt' => 'Left sidebar',
								'img' => get_template_directory_uri() . '/images/framework/leftsidebar.gif',
							),
							'4' => array(
								'alt' => 'Right sidebar',
								'img' => get_template_directory_uri() . '/images/framework/rightsidebar.gif',
							),
						),
						'default'     => '1',
					),
					array(
						'id'       => 'left_sidebar_widgets',
						'type'     => 'select',
						'title'    => esc_attr__( 'Widgets for Left Sidebar', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => array( '_default_left_sidebar' => 'Left Sidebar', ),
						'default'  => '_default_left_sidebar',
						'required' => array( 'sidebar-layout', '<', '0' ),
					),
					array(
						'id'       => 'right_sidebar_widgets',
						'type'     => 'select',
						'title'    => esc_attr__( 'Widgets for Right Sidebar', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => array( '_default_right_sidebar' => 'Right Sidebar', ),
						'default'  => '_default_right_sidebar',
						'required' => array( 'sidebar-layout', '<', '0' ),
					),


				),
			) );


		// Portfolio Design Tab
		Redux::setSection( $this->opt_name,
			array(
				'title'  => esc_attr__( 'Portfolio', 'addys' ),
				'id'     => 'services-subsection',
				'icon'   => 'el el-brush',
				'fields' => array(


					array(
						'id'    => 'cases-info1',
						'type'  => 'info',
						'style' => 'info',
						'title' => esc_attr__( 'Options for Portfolio Post Type', 'addys' ),
					),

					array(
						'id'          => 'portfolio_slug',
						'type'        => 'text',
						'title'       => esc_attr__( 'URL Slug For Portfolio Post Type', 'addys' ),
						'description' => wp_kses( __( ' After you change it, go to <a href="options-permalink.php" target="_blank">/wp-admin/options-permalink.php</a> and click "Save Changes" button to activate the URL slug', 'addys' ), $this->allowed_html ),
						'default'     => 'portfolio',
					),
					array(
						'id'       => 'cases_arch_title',
						'type'     => 'text',
						'title'    => esc_attr__( 'Portfolio Page H1 Heading', 'addys' ),
						'subtitle' => esc_attr__( 'Heading for Portfolio Archive page', 'addys' ),
						'default'  => 'Case Studies List',
					),
					array(
						'id'       => 'portfolio_arch_desc',
						'type'     => 'editor',
						'title'    => esc_attr__( 'Description Text Under H1 Heading', 'addys' ),
						'subtitle' => esc_attr__( 'Allowed tags: a, img, br, em, strong, h1, h2, h3, h4, h5, h6, p, b, i, u, ol, ul, li, code, del',
							'addys' ),
						'default'  => 'Some description text here',
					),


				),
			) );


		Redux::setSection( $this->opt_name,
			array(
				'title' => esc_attr__( 'Color Scheme', 'addys' ),
				'id'    => 'ocs',
				'desc'  => esc_attr__( 'Color scheme of the current design. You can create your own color scheme.',
					'addys' ),
				'icon'  => 'el el-cog',

				'fields' => array(
					array(
						'id'     => 'colors_info_notice',
						'type'   => 'info',
						'notice' => true,
						'style'  => 'info',
						'icon'   => 'el-icon-info-sign',
						'title'  => esc_attr__( 'Note', 'addys' ),
						'desc'   => esc_attr__( 'We recommend to export and save theme options setting before change everything.',
							'addys' ),
					),
					
					//Section START
					array(
						'id'     => 'general-colors-section-start',
						'type'   => 'section',
						'title'  => esc_attr__( 'General Colors', 'addys' ),
						'indent' => true, // Indent all options below until the next 'section' option is set.
					),
					array(
						'id'       => 'gc1',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Major Color', 'addys' ),
						'default'  => array(
							'color' => '#e35c5c',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),
					array(
						'id'       => 'gc1d',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Dark Major Color', 'addys' ),
						'default'  => array(
							'color' => '#333333',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),

					array(
						'id'       => 'link',
						'type'     => 'link_color',
						'title'    => esc_attr__( 'Links Color Option', 'addys' ),
						'visited'  => false,  // Disable Visited Color
						'default'  => array(
							'regular' => '#e35c5c',
							'hover'   => '#e35c5c',
							'active'  => '#e35c5c',
						),
						'compiler' => true,
						'output'   => 'a',
					),
					array(
						'id'       => 'gc2',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Minor Color', 'addys' ),
						'default'  => array(
							'color' => '#e35c5c',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),
					array(
						'id'       => 'gc2d',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Dark Minor Color', 'addys' ),
						'default'  => array(
							'color' => '#e35c5c',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),

					array(
						'id'       => 'bgrc',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Background Color', 'addys' ),
						'default'  => array(
							'color' => '#ffffff',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),

					array(
						'id'     => 'general-colors-section-end',
						'type'   => 'section',
						'indent' => false, // Indent all options below until the next 'section' option is set.
					),
					// Section END


					//Section START
					array(
						'id'     => 'additional-colors-section-start',
						'type'   => 'section',
						'title'  => esc_attr__( 'Additional Colors', 'addys' ),
						'indent' => true, // Indent all options below until the next 'section' option is set.
					),

					array(
						'id'       => 'ac1',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Gray Color', 'addys' ),
						'default'  => array(
							'color' => '#a19b9b',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),
					array(
						'id'       => 'ac1l',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Gray Color Light', 'addys' ),
						'default'  => array(
							'color' => '#d6c8c8',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),
					array(
						'id'       => 'ac1d',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Gray Color Dark', 'addys' ),
						'default'  => array(
							'color' => '#555555',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),


					array(
						'id'     => 'additional-colors-section-end',
						'type'   => 'section',
						'indent' => false, // Indent all options below until the next 'section' option is set.
					),
					// Section END

				),

			) );


		/*
		 * <--- END SECTIONS
		 */
		Redux::setSection( $this->opt_name,
			array(
				'title'  => esc_attr__( 'Design', 'addys' ),
				'id'     => 'design',
				'icon'   => 'el el-tasks',
				'fields' => array(
					array(
						'id'    => 'design-info1',
						'type'  => 'info',
						'style' => 'info',
						'title' => esc_attr__( 'Options for major design styles', 'addys' ),
					),
					array(
						'id'             => 'boxed-padding',
						'type'           => 'spacing',
						'output'         => array( 'body main.boxed-wrapper' ),
						'mode'           => 'padding',
						'units'          => array( 'em', 'px' ),
						'units_extended' => 'false',
						'title'          => esc_attr__( 'Padding Option for Boxed Background', 'addys' ),
						'default'        => array(
							'padding-top'    => '',
							'padding-right'  => '',
							'padding-bottom' => '',
							'padding-left'   => '',
							'units'          => 'px',
						),
					),
					array(
						'id'    => 'design-info2',
						'type'  => 'info',
						'style' => 'info',
						'title' => esc_attr__( 'Sidebars design styles', 'addys' ),
					),
					array(
						'id'       => 'sidebar-bgr',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Sidebars Background Color', 'addys' ),
						'default'  => array(
							'color' => '#f1f4f6',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),
					array(
						'id'             => 'sidebar-padding',
						'type'           => 'spacing',
						'output'         => array( 'main .widget-area >div, html .sidebar-type' ),
						'mode'           => 'padding',
						'units'          => array( 'em', 'px' ),
						'units_extended' => 'false',
						'title'          => esc_attr__( 'Padding Option for Sidebar', 'addys' ),
						'default'        => array(
							'padding-top'    => '0',
							'padding-right'  => '15',
							'padding-bottom' => '0',
							'padding-left'   => '15',
							'units'          => 'px',
						),
					),
					array(
						'id'     => 'sidebar-border',
						'type'   => 'border',
						'title'  => esc_attr__( 'Border Option for Sidebar', 'addys' ),
						'output' => array( 'main .widget-area >div, html .sidebar-type' ),
						// An array of CSS selectors to apply this font style to

						'default' => array(
							'border-color'  => '#ffffff',
							'border-style'  => 'solid',
							'border-top'    => '1px',
							'border-right'  => '1px',
							'border-bottom' => '1px',
							'border-left'   => '1px',
						),
					),
					array(
						'id'            => 'sidebar-border-radius',
						'type'          => 'slider',
						'title'         => esc_attr__( 'Border Radius', 'addys' ),
						'desc'          => esc_attr__( 'Select border radius in px. Min: 0, max: 100, step: 1, default value: 0',
							'addys' ),
						'default'       => '0',
						'min'           => 0,
						'step'          => 1,
						'max'           => 100,
						'display_value' => 'text',
					),

					array(
						'id'             => 'sidebar-width',
						'type'           => 'dimensions',
						'output'         => array( 'main .widget-area >div, html .sidebar-type' ),
						'units'          => array( 'em', 'px', '%' ),
						// You can specify a unit value. Possible: px, em, %
						'units_extended' => 'true',
						// Allow users to select any type of unit
						'title'          => esc_attr__( 'Sidebar Width', 'addys' ),
						'desc'           => esc_attr__( 'Total content zone width is 1170px. If you turn 2 sidebars on, remember about it.',
							'addys' ),
						'height'         => false,
						'default'        => array(
							'width'  => '',
							
						),
					),
					array(
						'id'             => 'content-width',
						'type'           => 'dimensions',
						'output'         => array( 'main .cont-box-area' ),
						'units'          => array( 'em', 'px', '%' ),
						// You can specify a unit value. Possible: px, em, %
						'units_extended' => 'true',
						// Allow users to select any type of unit
						'title'          => esc_attr__( 'Content Column Width', 'addys' ),
						'desc'           => esc_attr__( 'Total content zone width is 1170px. If you turn 2 sidebars on, remember about it.',
							'addys' ),
						'height'         => false,
						'default'        => array(
							'width'  => '',
							
						),
					),
					array(
						'id'             => 'content-padding',
						'type'           => 'spacing',
						'output'         => array( 'main .cont-box-area' ),
						'mode'           => 'padding',
						'units'          => array( 'em', 'px' ),
						'units_extended' => 'false',
						'title'          => esc_attr__( 'Padding Option for Content Column', 'addys' ),
						'default'        => array(
							'padding-top'    => '0',
							'padding-right'  => '15',
							'padding-bottom' => '0',
							'padding-left'   => '15',
							'units'          => 'px',
						),
					),


					array(
						'id'    => 'design-info3',
						'type'  => 'info',
						'style' => 'info',
						'title' => esc_attr__( 'Buttons design styles', 'addys' ),
					),
					array(
						'id'             => 'button-padding',
						'type'           => 'spacing',
						'output'         => array( 'main button, main input[type="button"], main input[type="reset"], main input[type="submit"]' ),
						'mode'           => 'padding',
						'units'          => array( 'em', 'px' ),
						'units_extended' => 'false',
						'title'          => esc_attr__( 'Padding Option for Buttons', 'addys' ),
						'default'        => array(
							'padding-top'    => '0',
							'padding-right'  => '40',
							'padding-bottom' => '0',
							'padding-left'   => '40',
							'units'          => 'px',
						),
					),
					array(
						'id'     => 'button-border',
						'type'   => 'border',
						'title'  => esc_attr__( 'Border Option for Buttons', 'addys' ),
						'output' => array( 'main button, main input[type="button"], main input[type="reset"], main input[type="submit"], main .form-submit input[type="submit"]' ),
						// An array of CSS selectors to apply this font style to

						'default' => array(
							'border-color'  => '#F55E66',
							'border-style'  => 'solid',
							'border-top'    => '1px',
							'border-right'  => '1px',
							'border-bottom' => '1px',
							'border-left'   => '1px',
						),
					),

					array(
						'id'       => 'button-color',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Buttons Background Color', 'addys' ),
						'default'  => array(
							'color' => '#ffffff',
							'alpha' => '0',
						),
						'compiler' => true,
						'output'   => false,

					),
					array(
						'id'       => 'button-text-color',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Buttons Text Color', 'addys' ),
						'default'  => array(
							'color' => '#F55E66',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),
					array(
						'id'     => 'button-border-hover',
						'type'   => 'border',
						'title'  => esc_attr__( 'Border Option for Buttons (hover)', 'addys' ),
						'output' => array( 'main button:hover, main input[type="button"]:hover, main input[type="reset"]:hover, main .form-submit input[type="submit"]:hover' ),
						// An array of CSS selectors to apply this font style to

						'default' => array(
							'border-color'  => '#F55E66',
							'border-style'  => 'solid',
							'border-top'    => '1px',
							'border-right'  => '1px',
							'border-bottom' => '1px',
							'border-left'   => '1px',
						),
					),
					array(
						'id'       => 'button-color-hover',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Buttons Background Color (hover)', 'addys' ),
						'default'  => array(
							'color' => '#F55E66',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),
					array(
						'id'       => 'button-text-color-hover',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Buttons Text Color (hover)', 'addys' ),
						'default'  => array(
							'color' => '#ffffff',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),
					array(
						'id'            => 'button-border-radius',
						'type'          => 'slider',
						'title'         => esc_attr__( 'Border Radius for Buttons', 'addys' ),
						'desc'          => esc_attr__( 'Select border radius in px. Min: 0, max: 100, step: 1, default value: 0',
							'addys' ),
						'default'       => '0',
						'min'           => 0,
						'step'          => 1,
						'max'           => 100,
						'display_value' => 'text',
					),


					array(
						'id'    => 'design-info4',
						'type'  => 'info',
						'style' => 'info',
						'title' => esc_attr__( 'Inputs design styles', 'addys' ),
					),
					array(
						'id'     => 'input-border',
						'type'   => 'border',
						'title'  => esc_attr__( 'Border Option for Inputs', 'addys' ),
						'output' => array( 'input[type="text"], input[type="email"], input[type="url"], input[type="password"], input[type="search"], input[type="number"], input[type="tel"], input[type="range"], input[type="date"], input[type="month"], input[type="week"], input[type="time"], input[type="datetime"], input[type="datetime-local"], input[type="color"], html body textarea, select.form-control,select,.select2-container a' ),
						// An array of CSS selectors to apply this font style to

						'default' => array(
							'border-color'  => '#cccccc',
							'border-style'  => 'solid',
							'border-top'    => '1px',
							'border-right'  => '1px',
							'border-bottom' => '1px',
							'border-left'   => '1px',
						),
					),
					array(
						'id'            => 'input-border-radius',
						'type'          => 'slider',
						'output'        => array( 'input[type="text"], input[type="email"], input[type="url"], input[type="password"], input[type="search"], input[type="number"], input[type="tel"], input[type="range"], input[type="date"], input[type="month"], input[type="week"], input[type="time"], input[type="datetime"], input[type="datetime-local"], input[type="color"], textarea' ),
						'title'         => esc_attr__( 'Border Radius for Inputs', 'addys' ),
						'desc'          => esc_attr__( 'Select border radius in px. Min: 0, max: 100, step: 1, default value: 0',
							'addys' ),
						'default'       => '0',
						'min'           => 0,
						'step'          => 1,
						'max'           => 100,
						'display_value' => 'text',
					),
					array(
						'id'       => 'input-color',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Inputs Background Color', 'addys' ),
						'default'  => array(
							'color' => '#ffffff',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),
					array(
						'id'       => 'input-text-color',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Inputs Text Color', 'addys' ),
						'default'  => array(
							'color' => '#292929',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),


				),
			) );


		// -> START Typography Settings Tab with no subsections
		Redux::setSection( $this->opt_name,
			array(
				'title'  => esc_attr__( 'Typography', 'addys' ),
				'id'     => 'typography',
				'icon'   => 'el el-font',
				'fields' => array(
					array(
						'id'     => 'typography-_info_notice',
						'type'   => 'info',
						'notice' => true,
						'style'  => 'info',
						'icon'   => 'el-icon-info-sign',
						'title'  => esc_attr__( 'Note', 'addys' ),
						'desc'   => esc_attr__( 'We recommend to use font pair: one font for body text and one for headings. You can find good font pair on',
								'addys' ) . ' <a href="http://fontpair.co/" target="_blank">http://fontpair.co/</a>',
					),
					array(
						'id'          => 'typography-body',
						'type'        => 'typography',
						'title'       => esc_attr__( 'Body Font', 'addys' ),
						'subtitle'    => esc_attr__( 'Specify the body font properties.', 'addys' ),
						'font-backup' => true,
						'google'      => true,
						'subsets'     => true,
						'default'     => array(
							'color'       => '#555555',
							'font-size'   => '17px',
							'font-family' => 'Josefin Sans',
							'font-weight' => '400',
							'text-align'  => 'left',
							'line-height' => '26px',
						),
					),
					array(
						'id'             => 'h1-typography',
						'type'           => 'typography',
						'title'          => esc_attr__( 'Heading H1 Font', 'addys' ),
						'subtitle'       => esc_attr__( 'Specify the H1 font properties.', 'addys' ),
						'font-backup'    => true,
						'google'         => true,
						'subsets'        => true,
						'text-transform' => true,
						'default'        => array(
							'color'          => '#333333',
							'font-weight'    => '600',
							'font-family'    => 'Dosis',
							'font-size'      => '45px',
							'line-height'    => '67px',
							'text-transform' => 'none',
							'text-align'     => 'center',
						),
					),

					array(
						'id'             => 'h2-typography',
						'type'           => 'typography',
						'title'          => esc_attr__( 'Heading H2 Font', 'addys' ),
						'subtitle'       => esc_attr__( 'Specify the H2 font properties.', 'addys' ),
						'font-backup'    => true,
						'google'         => true,
						'subsets'        => true,
						'text-transform' => true,
						'default'        => array(
							'color'          => '#333333',
							'font-weight'    => '600',
							'font-family'    => 'Dosis',
							'font-size'      => '35px',
							'line-height'    => '45px',
							'text-transform' => 'none',
							'text-align'     => 'center',
						),
					),
					array(
						'id'             => 'h3-typography',
						'type'           => 'typography',
						'title'          => esc_attr__( 'Heading H3 Font', 'addys' ),
						'subtitle'       => esc_attr__( 'Specify the H3 font properties.', 'addys' ),
						'font-backup'    => true,
						'google'         => true,
						'subsets'        => true,
						'text-transform' => true,
						'default'        => array(
							'color'          => '#333333',
							'font-weight'    => '600',
							'font-family'    => 'Dosis',
							'font-size'      => '30px',
							'line-height'    => '38px',
							'text-transform' => 'none',
							'text-align'     => 'center',
						),
					),

					array(
						'id'             => 'reserved-typography',
						'type'           => 'typography',
						'title'          => esc_attr__( 'Reserved Font', 'addys' ),
						'subtitle'       => esc_attr__( 'Connects the font.', 'addys' ),
						'font-backup'    => false,
						'google'         => true,
						'subsets'        => true,
						'text-transform' => false,
						'text-align'     => false,
						'font-size'      => false,
						'line-height'    => false,
						'color'          => false,
						'default'        => array(
							'font-family' => 'Roboto',
							'font-weight' => '300',
						),
					),
					array(
						'id'             => 'reserved2-typography',
						'type'           => 'typography',
						'title'          => esc_attr__( 'Reserved Font #2', 'addys' ),
						'subtitle'       => esc_attr__( 'Connects the font.', 'addys' ),
						'font-backup'    => false,
						'google'         => true,
						'subsets'        => true,
						'text-transform' => false,
						'text-align'     => false,
						'font-size'      => false,
						'line-height'    => false,
						'color'          => false,
						'default'        => array(
							'font-family' => 'Roboto',
							'font-weight' => '700',
						),
					),
					array(
						'id'             => 'reserved3-typography',
						'type'           => 'typography',
						'title'          => esc_attr__( 'Reserved Font #3', 'addys' ),
						'subtitle'       => esc_attr__( 'Connects the font.', 'addys' ),
						'font-backup'    => false,
						'google'         => true,
						'subsets'        => true,
						'text-transform' => false,
						'text-align'     => false,
						'font-size'      => false,
						'line-height'    => false,
						'color'          => false,
						'default'        => array(
							'font-family' => '',
							'font-weight' => '',
						),
					),
					array(
						'id'             => 'reserved4-typography',
						'type'           => 'typography',
						'title'          => esc_attr__( 'Reserved Font #4', 'addys' ),
						'subtitle'       => esc_attr__( 'Connects the font.', 'addys' ),
						'font-backup'    => false,
						'google'         => true,
						'subsets'        => true,
						'text-transform' => false,
						'text-align'     => false,
						'font-size'      => false,
						'line-height'    => false,
						'color'          => false,
						'default'        => array(
							'font-family' => '',
							'font-weight' => '',
						),
					),
					array(
						'id'             => 'reserved5-typography',
						'type'           => 'typography',
						'title'          => esc_attr__( 'Reserved Font #5', 'addys' ),
						'subtitle'       => esc_attr__( 'Connects the font.', 'addys' ),
						'font-backup'    => false,
						'google'         => true,
						'subsets'        => true,
						'text-transform' => false,
						'text-align'     => false,
						'font-size'      => false,
						'line-height'    => false,
						'color'          => false,
						'default'        => array(
							'font-family' => '',
							'font-weight' => '',
						),
					),
					array(
						'id'     => 'typography-_info_notice_2',
						'type'   => 'info',
						'notice' => true,
						'style'  => 'info',
						'icon'   => 'el-icon-info-sign',
						'title'  => esc_attr__( 'Responsive Default Fonts', 'addys' ),
						'desc'   => esc_attr__( 'Fonts settings for mobile version under width resolution 600px ',
							'addys' ),
					),
					array(
						'id'          => 'typography-body-m',
						'type'        => 'typography',
						'title'       => esc_attr__( 'Body Font', 'addys' ),
						'subtitle'    => esc_attr__( 'Specify the body font properties.', 'addys' ),
						'font-backup' => true,
						'google'      => true,
						'subsets'     => true,
						'default'     => array(
							'color'       => '#2c3840',
							'font-size'   => '16px',
							'font-family' => 'Roboto',
							'font-weight' => '400',
							'text-align'  => 'left',
							'line-height' => '26px',
						),
					),
					array(
						'id'             => 'h1-typography-m',
						'type'           => 'typography',
						'title'          => esc_attr__( 'Heading H1 Font', 'addys' ),
						'subtitle'       => esc_attr__( 'Specify the H1 font properties.', 'addys' ),
						'font-backup'    => true,
						'google'         => true,
						'subsets'        => true,
						'text-transform' => true,
						'default'        => array(
							'color'          => '#333333',
							'font-weight'    => '600',
							'font-family'    => 'Dosis',
							'font-size'      => '35px',
							'line-height'    => '57px',
							'text-transform' => 'none',
							'text-align'     => 'center',
						),
					),


				),
			) );


		/*
		 * <--- END SECTIONS
		 */
		Redux::setSection( $this->opt_name,
			array(
				'title'  => esc_attr__( 'Translate', 'addys' ),
				'id'     => 'translate',
				'icon'   => 'el el-list-alt',
				'fields' => array(
					array(
						'id'    => '404-info1',
						'type'  => 'info',
						'style' => 'info',
						'title' => esc_attr__( 'Text for 404 error page', 'addys' ),
					),
					array(
						'id'      => '404_title',
						'type'    => 'text',
						'title'   => esc_attr__( '404 Page Heading', 'addys' ),
						'default' => esc_attr__( 'Not Found', 'addys' ),
					),
					array(
						'id'      => '404_descr',
						'type'    => 'text',
						'title'   => esc_attr__( '404 Page Description', 'addys' ),
						'default' => esc_attr__( 'It looks like nothing was found at this location. Maybe try a search?',
							'addys' ),
					),
					array(
						'id'    => '404_icon',
						'type'  => 'media',
						'url'   => true,
						'title' => esc_attr__( 'Icon On 404 Error Page', 'addys' ),

						'default' => array(
							'url' => esc_url( get_template_directory_uri() ) . '/images/search.png',
						),
					),
				),
			) );

		/* Start Custom Section */

		Redux::setSection( $this->opt_name,
			array(
				'title'  => esc_attr__( 'Custom CSS/JS', 'addys' ),
				'id'     => 'custom_settings',
				'desc'   => esc_attr__( 'Your settings for customization', 'addys' ),
				'icon'   => 'el el-file-edit',
				'fields' => array(


					array(
						'id'       => 'header-nested',
						'type'     => 'switch',
						'title'    => esc_attr__( 'Header Section JS, CSS editors', 'addys' ),
						'subtitle' => esc_attr__( 'Click On to choice of editors to appear.', 'addys' ),
						'default'  => false,
					),
					array(
						'id'       => 'header-nested-buttonset',
						'type'     => 'button_set',
						'subtitle' => esc_attr__( 'This code will appear in the HEADER secrion of the site',
							'addys' ),
						'options'  => array(
							'button-js'  => 'JS editor',
							'button-css' => 'CSS editor',
						),
						'required' => array( 'header-nested', '=', true ),
						'default'  => 'button-js',
					),

					array(
						'id'       => 'header-nested-ace-js',
						'type'     => 'ace_editor',
						'mode'     => 'javascript',
						'title'    => esc_attr__( 'JS Editor', 'addys' ),
						'default'  => '// function hello() { alert ("HELLO"); }',
						'required' => array( 'header-nested-buttonset', '=', 'button-js' ),
					),

					array(
						'id'       => 'header-nested-ace-css',
						'type'     => 'ace_editor',
						'mode'     => 'css',
						'title'    => esc_attr__( 'CSS Editor', 'addys' ),
						'default'  => 'body { margin : 0; padding : 0; }',
						'required' => array( 'header-nested-buttonset', '=', 'button-css' ),
					),

					array(
						'id'       => 'footer-nested',
						'type'     => 'switch',
						'title'    => esc_attr__( 'Footer Section JS, CSS editors', 'addys' ),
						'subtitle' => esc_attr__( 'Click On to choice of editors to appear.', 'addys' ),
						'default'  => false,
					),
					array(
						'id'       => 'footer-nested-buttonset',
						'type'     => 'button_set',
						'subtitle' => esc_attr__( 'This code will appear in the FOOTER secrion of the site',
							'addys' ),
						'options'  => array(
							'button-js'  => 'JS editor',
							'button-css' => 'CSS editor',
						),
						'required' => array( 'footer-nested', '=', true ),
						'default'  => 'button-js',
					),

					array(
						'id'       => 'footer-nested-ace-js',
						'type'     => 'ace_editor',
						'mode'     => 'javascript',
						'title'    => esc_attr__( 'JS Editor', 'addys' ),
						'default'  => 'function hello() { alert ("HELLO"); }',
						'required' => array( 'footer-nested-buttonset', '=', 'button-js' ),
					),

					array(
						'id'       => 'footer-nested-ace-css',
						'type'     => 'ace_editor',
						'mode'     => 'css',
						'title'    => esc_attr__( 'CSS Editor', 'addys' ),
						'default'  => 'body { margin : 0; padding : 0; }',
						'required' => array( 'footer-nested-buttonset', '=', 'button-css' ),
					),
				),
			) );

		/*
		 * <--- END SECTIONS
		 */
		// -> START Shop Settings Tab with no subsections
		Redux::setSection( $this->opt_name,
			array(
				'title'  => esc_attr__( 'Shop', 'addys' ),
				'id'     => 'shop-setting',
				'icon'   => 'el el-shopping-cart',
				'fields' => array(
					array(
						'id'       => 'shop-header_type',
						'type'     => 'select',
						'title'    => esc_attr__( 'Choose Header type', 'addys' ),
						'options'  => array( 1 => 'Slider', ),
						'default'  => 1,
						'required' => array( 'header_type', '<', '0' ),
					),

					array(
						'id'       => 'shop-pick_slider',
						'type'     => 'select',
						'title'    => esc_attr__( 'Select Slider for Shop', 'addys' ),
						'subtitle' => esc_attr__( 'Select slider for header section', 'addys' ),
						'options'  => Secret_Lab_Config::get_sliders_array(),
						'default'  => '0',
					),
					array(
						'id'       => 'shop1',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Price Color', 'addys' ),
						'default'  => array(
							'color' => '#ce0000',
							'alpha' => '1',
						),
						'compiler' => true,
						'output'   => false,
					),

					array(
						'id'       => 'product_columns',
						'type'     => 'text',
						'title'    => esc_attr__( 'Columns of Products', 'addys' ),
						'subtitle' => esc_attr__( 'For catalog and categories pages', 'addys' ),
						'default'  => '4',
					),
					array(
						'id'       => 'relates_product_products',
						'type'     => 'text',
						'title'    => esc_attr__( 'Related Products to show', 'addys' ),
						'subtitle' => esc_attr__( 'For product page', 'addys' ),
						'default'  => '4',
					),
					array(
						'id'       => 'relates_product_columns',
						'type'     => 'text',
						'title'    => esc_attr__( 'Columns of related products', 'addys' ),
						'subtitle' => esc_attr__( 'For product page', 'addys' ),
						'default'  => '4',
					),

					array(
						'id'       => 'shop-layout',
						'type'     => 'image_select',
						'title'    => esc_attr__( 'Select shop page layout', 'addys' ),
						'subtitle' => esc_attr__( 'The option work for slug /shop/', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => array(
							'1' => array(
								'alt' => 'Full width layout',
								'img' => get_template_directory_uri() . '/images/framework/full.gif',
							),
							'2' => array(
								'alt' => 'Boxed layout, maximum resolution - 1170 px',
								'img' => get_template_directory_uri() . '/images/framework/boxed.gif',
							),
						),
						'default'  => '1',
					),
					array(
						'id'       => 'shop-boxed-background',
						'type'     => 'background',
						'title'    => esc_attr__( 'Background settings for box', 'addys' ),
						'output'   => array( '.woocommerce-page .mainbgr', ),
						'default'  => array(
							'background-color'      => '#323232',
							'background-repeat'     => 'no-repeat',
							'background-attachment' => 'fixed',
							'background-position'   => 'center center',
							'background-size'       => 'inherit',
						),
						'required' => array( 'shop-layout', '=', '2' ),
					),
					array(
						'id'      => 'shop-content-background',
						'type'    => 'background',
						'title'   => esc_attr__( 'Background settings for content section', 'addys' ),
						'output'  => array( '.woocommerce-page main' ),
						'default' => array(
							'background-color'      => '#ffffff',
							'background-repeat'     => 'no-repeat',
							'background-attachment' => 'fixed',
							'background-position'   => 'center center',
							'background-size'       => 'inherit',
						),
					),

					array(
						'id'      => 'shop-sidebar-layout',
						'type'    => 'image_select',
						'title'   => esc_attr__( 'Select sidebar option for shop', 'addys' ),

						//Must provide key => value(array:title|img) pairs for radio options
						'options' => array(
							'1' => array(
								'alt' => 'Without sidebar',
								'img' => get_template_directory_uri() . '/images/framework/nosidebar.gif',
							),
							'2' => array(
								'alt' => '2 sidebars',
								'img' => get_template_directory_uri() . '/images/framework/2sidebars.gif',
							),
							'3' => array(
								'alt' => 'Left sidebar',
								'img' => get_template_directory_uri() . '/images/framework/leftsidebar.gif',
							),
							'4' => array(
								'alt' => 'Right sidebar',
								'img' => get_template_directory_uri() . '/images/framework/rightsidebar.gif',
							),
						),
						'default' => '0',
					),
					array(
						'id'       => 'shop_left_sidebar_widgets',
						'type'     => 'select',
						'title'    => esc_attr__( 'Widgets for Shop Left Sidebar', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => array( 'shop_default_left_sidebar' => 'Left Shop Sidebar', ),
						'default'  => 'shop_default_left_sidebar',
						'required' => array( 'shop-sidebar-layout', '<', '0' ),
					),
					array(
						'id'       => 'shop_right_sidebar_widgets',
						'type'     => 'select',
						'title'    => esc_attr__( 'Widgets for Shop Right Sidebar', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => array( 'shop_default_right_sidebar' => 'Right Shop Sidebar', ),
						'default'  => 'shop_default_right_sidebar',
						'required' => array( 'shop-sidebar-layout', '<', '0' ),
					),

					array(
						'id'      => 'shop_header_widget',
						'type'    => 'select',
						'title'   => esc_attr__( 'Select Header for Shop', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options' => Secret_Lab_Config::get_composer_block_array( 'header' ),
						'default' => '1833',
					),


					array(
						'id'      => 'shop_footer_widget',
						'type'    => 'select',
						'title'   => esc_attr__( 'Select Footer for Shop', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options' => Secret_Lab_Config::get_composer_block_array( 'footer' ),
						'default' => '1848',
					),
					array(
						'id'      => 'woocomp',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Enable company field in checkout', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'wooadd1',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Enable address 1 field in checkout', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'wooadd2',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Enable address 2 field in checkout', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'woostate',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Enable state field in checkout', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'woocity',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Enable city field in checkout', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'woophone',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Enable phone field in checkout', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'woopostcode',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Enable postcode field in checkout', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'woocountry',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Enable country field in checkout', 'addys' ),
						'default' => true,
					),

				),
			) );

		// -> START BLOG SECTION
		Redux::setSection( $this->opt_name,
			array(
				'title'  => esc_attr__( 'Blog', 'addys' ),
				'id'     => 'blog-setting',
				'icon'   => 'el el-blogger',
				'fields' => array(
					array(
						'id'       => 'blog-sidebar-layout',
						'type'     => 'image_select',
						'title'    => esc_attr__( 'Choose sidebar option for blog', 'addys' ),
						'subtitle' => esc_attr__( 'The option work for POST post type', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => array(
							'1' => array(
								'alt' => 'Without sidebar',
								'img' => get_template_directory_uri() . '/images/framework/nosidebar.gif',
							),
							'2' => array(
								'alt' => '2 sidebars',
								'img' => get_template_directory_uri() . '/images/framework/2sidebars.gif',
							),
							'3' => array(
								'alt' => 'Left sidebar',
								'img' => get_template_directory_uri() . '/images/framework/leftsidebar.gif',
							),
							'4' => array(
								'alt' => 'Right sidebar',
								'img' => get_template_directory_uri() . '/images/framework/rightsidebar.gif',
							),
						),
						'default'  => '1',
					),
					array(
						'id'       => 'blog_left_sidebar_widgets',
						'type'     => 'select',
						'title'    => esc_attr__( 'Widgets for Blog Left Sidebar', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => array( 'blog_default_left_sidebar' => 'Left Blog Sidebar', ),
						'default'  => 'blog_default_left_sidebar',
						'required' => array( 'blog-sidebar-layout', '<', '0' ),
					),
					array(
						'id'       => 'blog_right_sidebar_widgets',
						'type'     => 'select',
						'title'    => esc_attr__( 'Widgets for Blog Right Sidebar', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => array( 'blog_default_right_sidebar' => 'Right Blog Sidebar', ),
						'default'  => 'blog_default_right_sidebar',
						'required' => array( 'blog-sidebar-layout', '<', '0' ),
					),

					array(
						'id'      => 'blog_header_widget',
						'type'    => 'select',
						'title'   => esc_attr__( 'Choose Header for Blog', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options' => Secret_Lab_Config::get_composer_block_array( 'header' ),
						'default' => '1833',
					),
					array(
						'id'       => 'blog-header_type',
						'type'     => 'select',
						'title'    => esc_attr__( 'Select Header type', 'addys' ),
						'options'  => array( 1 => 'Slider', ),
						'default'  => 1,
						'required' => array( 'header_type', '<', '0' ),
					),

					array(
						'id'       => 'blog-pick_slider',
						'type'     => 'select',
						'title'    => esc_attr__( 'Select Slider for Blog', 'addys' ),
						'subtitle' => esc_attr__( 'The option work for Post post type', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => Secret_Lab_Config::get_sliders_array(),
						'default'  => '0',
					),
					array(
						'id'             => 'blog-title-typography',
						'type'           => 'typography',
						'title'          => esc_attr__( 'Blog Category Heading', 'addys' ),
						'subtitle'       => esc_attr__( 'Specify the blog category heading font  properties.', 'addys' ),
						'font-backup'    => true,
						'google'         => true,
						'subsets'        => true,
						'text-transform' => true,
						'default'        => array(
							'color'          => '#333333',
							'font-weight'    => '400',
							'font-family'    => 'Josefin Sans',
							'font-size'      => '24px',
							'line-height'    => '30px',
							'text-transform' => 'capitalize',
							'text-align'     => 'left',
						),
					),





					array(
						'id'       => 'blog-layout',
						'type'     => 'image_select',
						'title'    => esc_attr__( 'Select page layout', 'addys' ),
						'subtitle' => esc_attr__( 'The option work for Post post type', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options'  => array(
							'1' => array(
								'alt' => 'Full width layout',
								'img' => get_template_directory_uri() . '/images/framework/full.gif',
							),
							'2' => array(
								'alt' => 'Boxed layout, maximum resolution - 1170 px',
								'img' => get_template_directory_uri() . '/images/framework/boxed.gif',
							),
						),
						'default'  => '1',

					),
					array(
						'id'       => 'blog-boxed-background',
						'type'     => 'background',
						'title'    => esc_attr__( 'Background settings for box', 'addys' ),
						'output'   => array( '.single-post .mainbgr', '.archive.category .mainbgr', ),
						'default'  => array(
							'background-color'      => '#323232',
							'background-repeat'     => 'no-repeat',
							'background-attachment' => 'fixed',
							'background-position'   => 'center center',
							'background-size'       => 'inherit',
						),
						'required' => array( 'blog-layout', '=', '2' ),
					),
					array(
						'id'      => 'blog-content-background',
						'type'    => 'background',
						'title'   => esc_attr__( 'Background settings for content section', 'addys' ),
						'output'  => array( '.single-post main', '.archive.category main', ),
						'default' => array(
							'background-color'      => '#ffffff',
							'background-repeat'     => 'no-repeat',
							'background-attachment' => 'fixed',
							'background-position'   => 'center center',
							'background-size'       => 'inherit',
							'background-image'      => '',
						),
					),



					array(
						'id'      => 'blog_footer_widget',
						'type'    => 'select',
						'title'   => esc_attr__( 'Choose Footer for Blog', 'addys' ),
						//Must provide key => value(array:title|img) pairs for radio options
						'options' => Secret_Lab_Config::get_composer_block_array( 'footer' ),
						'default' => '1848',
					),
					array(
						'id'   => 'blog-opt-divide1',
						'type' => 'divide',
					),
					array(
						'id'       => 'cases-info-BLOG',
						'type'     => 'info',
						'style'    => 'info',
						'title'    => esc_attr__( 'Blog Heading Box', 'addys' ),
					),
					array(
						'id'       => 'blog-custom-heading',
						'type'     => 'switch',
						'title'    => esc_attr__( 'Enable Blog Heading Box?', 'addys' ),
						'subtitle' => esc_attr__( 'It is a custom heading on blog, category, archive, post  pages', 'addys' ),
						'default'  => true,
					),

					array(
						'id'       => 'blog-heading-background',
						'type'     => 'background',
						'title'    => esc_attr__( 'Background settings for the heading box on the blog', 'addys' ),
						'output'   => array( '.custblog'),
						'compiler' => false,
						//'output'   => false,
						'default'  => array(
							'background-color'      => '#FFFFFF',
							'background-repeat'     => 'no-repeat',
							'background-attachment' => 'fixed',
							'background-position'   => 'center center',
							'background-size'       => 'inherit',
						),
						'required' => array( 'blog-custom-heading', '=', true ),
					),
					array(
						'id'       => 'bgfrom',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Gradient Underlay for Background From', 'addys' ),
						'default'  => array(
							'color' => '#F45769',
							'alpha' => '0',
						),
						'compiler' => true,'output'   => false,
						'required' => array( 'blog-custom-heading', '=', true ),
					),
					array(
						'id'       => 'bgto',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Gradient Underlay for Background To', 'addys' ),
						'default'  => array(
							'color' => '#F6964D',
							'alpha' => '0',
						),
						'compiler' => true,'output'   => false,
						'required' => array( 'blog-custom-heading', '=', true ),
					),
					array(
						'id'       => 'bgfromo',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Gradient Overlay for Background From', 'addys' ),
						'default'  => array(
							'color' => '#F45769',
							'alpha' => '0',
						),
						'compiler' => true,'output'   => false,
						'required' => array( 'blog-custom-heading', '=', true ),
					),
					array(
						'id'       => 'bgtoo',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Gradient Overlay for Background To', 'addys' ),
						'default'  => array(
							'color' => '#F6964D',
							'alpha' => '0',
						),
						'compiler' => true,'output'   => false,
						'required' => array( 'blog-custom-heading', '=', true ),
					),

					array(
						'id'             => 'blog-heading-padding',
						'type'           => 'spacing',
						'output'   => array( '.custblog'),
						'compiler' => false,
						'mode'           => 'padding',
						'units'          => array( 'em', 'px' ),
						'units_extended' => 'false',
						'title'          => esc_attr__( 'Padding Option for Heading Box', 'addys' ),
						'default'        => array(
							'padding-top'    => '55',
							'padding-right'  => '55',
							'padding-bottom' => '45',
							'padding-left'   => '55',
							'units'          => 'px',
						),
						'required' => array( 'blog-custom-heading', '=', true ),
					),
					array(
						'id'       => 'blog-heading-cat-text',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Category Link Text Color', 'addys' ),
						'default'  => array(
							'color' => '#555555',
							'alpha' => '1',
						),
						'output'   => array( '.single .entry-header ul.post-categories li a'),
						'compiler' => false,
						'required' => array( 'blog-custom-heading', '=', true ),
					),
					array(
						'id'       => 'blog-heading-cat-bgr',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Category Link Background Color', 'addys' ),
						'default'  => array(
							'color' => '#FFFFFF',
							'alpha' => '0',
						),
						'output'   => array( '.single .entry-header ul.post-categories li a'),
						'compiler' => false,
						'required' => array( 'blog-custom-heading', '=', true ),
					),
					array(
						'id'     => 'blog-heading-cat-border',
						'type'   => 'border',
						'title'  => esc_attr__( 'Category Link Border', 'addys' ),
						'output'   => array( '.single .entry-header ul.post-categories li a'),
						'compiler' => false,
						'default' => array(
							'border-color'  => '#FFFFFF',
							'border-style'  => 'solid',
							'border-top'    => '1px',
							'border-right'  => '1px',
							'border-bottom' => '1px',
							'border-left'   => '1px',
						),
						'required' => array( 'blog-custom-heading', '=', true ),
					),
					array(
						'id'            => 'blog-heading-cat-radius',
						'type'          => 'slider',
						'title'         => esc_attr__( 'Category Link Border Radius', 'addys' ),
						'desc'          => esc_attr__( 'Select border radius in px. Min: 0, max: 20, step: 1, default value: 0', 'addys' ),
						'output'   => array( '.single .entry-header ul.post-categories li a'),
						'compiler' => false,
						'default'       => '0',
						'min'           => 0, 'step'          => 1, 'max'           => 20,
						'display_value' => 'text',
						'required' => array( 'blog-custom-heading', '=', true ),
					),

					array(
						'id'       => 'blog-heading-h1-color',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'H1 Heading Text Color', 'addys' ),
						'default'  => array(
							'color' => '#333333',
							'alpha' => '1',
						),
						'compiler' => true,'output'   => false,
						'required' => array( 'blog-custom-heading', '=', true ),
					),
					array(
						'id'       => 'blog-heading-meta-color',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Meta Data Text Color', 'addys' ),
						'default'  => array(
							'color' => '#333333',
							'alpha' => '1',
						),
						'compiler' => true,'output'   => false,
						'required' => array( 'blog-custom-heading', '=', true ),
					),



					array(
						'id'   => 'blog-opt-divide1',
						'type' => 'divide',
					),
					/*======== Slider OR Image END ==========*/
					array(
						'id'            => 'thumb-border-radius',
						'type'          => 'slider',
						'title'         => esc_attr__( 'Border Radius for blog elements', 'addys' ),
						'desc'          => esc_attr__( 'Select border radius in px. Min: 0, max: 100, step: 1, default value: 0',
							'addys' ),
						'default'       => '12',
						'min'           => 0,
						'step'          => 1,
						'max'           => 100,
						'display_value' => 'text',
					),
					array(
						'id'       => 'post-header',
						'type'     => 'switch',
						'title'    => esc_attr__( 'Display Post H1 Heading', 'addys' ),
						'subtitle' => esc_attr__( 'Do you want to show H1 heading for post? Usually we display it through drag&drop builder',
							'addys' ),
						'default'  => false,
						'indent'   => false,
					),
					array(
						'id'       => 'is_related_posts',
						'type'     => 'switch',
						'title'    => esc_attr__( 'Related Posts for Single Post View', 'addys' ),
						'subtitle' => esc_attr__( 'Press On to template choice appear', 'addys' ),
						'default'  => true,
					),
					array(
						'id'       => 'related_posts_title',
						'type'     => 'text',
						'title'    => esc_attr__( 'Related Posts Title', 'addys' ),
						'subtitle' => esc_attr__( 'Set Title for Related Posts section', 'addys' ),
						'required' => array( 'is_related_posts', '=', true ),
						'default'  => 'Related Posts',
					),

					array(
						'id'      => 'show_post_author',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Show Post Author ', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'show_post_category',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Show Post Category ', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'show_post_tags',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Show Post Tags ', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'show_post_date',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Show Post Date ', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'show_comments_count',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Show Post Comments count ', 'addys' ),
						'default' => true,
					),
					array(
						'id'      => 'show_read_more',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Show Read More Link', 'addys' ),
						'default' => false,
					),
					array(
						'id'       => 'read_more_text',
						'type'     => 'text',
						'title'    => esc_attr__( 'Read More Link Text', 'addys' ),
						'subtitle' => esc_attr__( 'Set Text for Read More Link', 'addys' ),
						'required' => array( 'show_read_more', '=', true ),
						'default'  => '',
					),
				),
			)
		);

		// Modal window options
		/*
		 * <--- END SECTIONS
		 */
		Redux::setSection( $this->opt_name,
			array(
				'title'  => esc_attr__( 'Modal Window', 'addys' ),
				'id'     => 'modal',
				'icon'   => 'el el-list-alt',
				'fields' => array(
					array(
						'id'    => 'modal-info',
						'type'  => 'info',
						'style' => 'info',
						'title' => esc_attr__( 'Option enabling you to display a modal window before a user leaves your website.',
							'addys' ),
					),
					array(
						'id'      => 'show_modal',
						'type'    => 'switch',
						'title'   => esc_attr__( 'Show Modal Window', 'addys' ),
						'default' => false,
					),
					array(
						'id'          => 'modal_window',
						'type'        => 'select',
						'data'        => 'posts',
						'args'        => array( 'post_type' => array( 'modal_window', ) ),
						'title'       => esc_attr__( 'Select Modal Window', 'addys' ),
						'description' => wp_kses( __( ' Create a new Modal Window <a href="post-new.php?post_type=modal_window" target="_blank">here</a>',
							'addys' ),
							$this->allowed_html ),
						'required'    => array( 'show_modal', '=', true ),
						'default'     => false,
					),
					array(
						'id'       => 'close-color',
						'type'     => 'color_rgba',
						'title'    => esc_attr__( 'Close Button Color', 'addys' ),
						'default'  => array(
							'color' => '#ffffff',
							'alpha' => '1',
						),
						'compiler' => false,
						'output'   => array( '#ouibounce-modal .modal > i' ),
					),

					array(
						'id'       => 'agressive_modal',
						'type'     => 'switch',
						'title'    => esc_attr__( 'Aggressive Mode', 'addys' ),
						'subtitle' => esc_attr__( 'The modal to be eligible to fire anytime the page is loaded/ reloaded',
							'addys' ),
						'default'  => false,
					),
					array(
						'id'       => 'time_modal',
						'type'     => 'text',
						'title'    => esc_attr__( 'Set a min time before Ouibounce fires, in seconds',
							'addys' ),
						'subtitle' => esc_attr__( 'By default, Ouibounce won\'t fire in the first second to prevent false positives, as it\'s unlikely the user will be able to exit the page within less than a second.',
							'addys' ),
						'default'  => '1000',
					),
					array(
						'id'       => 'day_modal',
						'type'     => 'text',
						'title'    => esc_attr__( 'Cookie expiration, in days', 'addys' ),
						'subtitle' => esc_attr__( 'Ouibounce sets a cookie by default to prevent the modal from appearing more than once per user. By default, the cookie will expire at the end of the session, which for most browsers is when the browser is closed entirely.',
							'addys' ),
						'default'  => '5',
					),
				),
			) );

		// This example assumes your secretlab_theme_opt_name is set to redux_demo, replace with your secretlab_theme_opt_name value
		add_action( 'redux/page/secretlab/enqueue', array( 'Secret_Lab_Config', 'add_panel_css' ) );

		add_filter( 'redux/options/secretlab/saved', array( $this, 'set_index_page' ) );

	}

	public static function get_sidebars() {
		$sidebars = array();
		foreach ( $GLOBALS['wp_registered_sidebars'] as $sb ) {
			$sidebars[ $sb['id'] ] = $sb['name'];
		}

		return $sidebars;
	}

	public static function get_sliders_array() {

		global $wpdb;

		$arr = array( 0 => 'none' );

		if ( class_exists( 'LS_Sliders' ) ) {
			$sliders = LS_Sliders::find();
			foreach ( $sliders as $slider ) {
				$arr[ 'lay_' . $slider['id'] ] = $slider['name'];
			}
		}

		if ( class_exists( 'RevSliderSlider' ) ) {
			$RsExists = count( $wpdb->get_results( "SELECT * FROM information_schema.tables WHERE table_schema = '" . $wpdb->dbname . "' AND table_name = '" . $wpdb->prefix . "revslider_sliders' LIMIT 1",
				ARRAY_A ) );
			if ( $RsExists > 0 ) {
				$revSliders = $wpdb->get_results( "SELECT title, alias FROM " . $wpdb->prefix . "revslider_sliders WHERE ( type is NULL OR type = '' )",
					ARRAY_A );
				if ( count( $revSliders ) > 0 ) {
					foreach ( $revSliders as $slider ) {
						$arr[ 'rev_' . $slider['alias'] ] = $slider['title'];
					}
				}
			}
		}

		if ( class_exists( 'SmartSlider3' ) ) {
			$sliders = $wpdb->get_results( "SELECT id, title FROM " . $wpdb->prefix . "nextend2_smartslider3_sliders" );
			if ( ! empty( $sliders ) ) {
				foreach ( $sliders as $slider ) {
					$arr[ 'smart_' . $slider->id ] = $slider->title;
				}
			}
		}

		if ( count( $arr ) === 1 ) {
			$arr = array(
				0 => esc_attr__( 'The Theme Support Layer Slider, Smart Slider and Slider Revolution, but couldn\'t find it. Install one of the plug-ins to choose the slider to display in the header.',
					'addys' ),
			);
		}

		return $arr;
	}

	public static function get_composer_block_array( $type = 'sidebar' ) {

		global $wpdb;

		$composer_block_array = array();
		if ( 'header' == $type || 'footer' == $type ) {
			$composer_block_array[ - 1 ] = 'None';
		}
		$composer_block_type = 'composer_block_' . $type;

		$query_arr = $wpdb->get_results( $wpdb->prepare( "SELECT pm.`post_id`, wps.`post_title` FROM $wpdb->postmeta pm INNER JOIN $wpdb->posts wps ON pm.post_id=wps.ID WHERE pm.meta_key = 'composer_block_type' AND pm.meta_value = '%s' AND wps.post_status = 'publish'",
			$composer_block_type ) );

		if ( is_array( $query_arr ) ) {
			foreach ( $query_arr as $composer_block_data ) {
				$composer_block_array[ $composer_block_data->post_id ] = $composer_block_data->post_title;
			}
		}

		return $composer_block_array;
	}


	/*=== Adding custom CSS for Theme Options design ===*/
	public static function add_panel_css() {
		wp_register_style(
			'redux-custom-css',
			esc_url( get_template_directory_uri() ) . '/inc/redux-custom-css.css',
			array( 'redux-admin-css' ),
			// Be sure to include redux-admin-css so it's appended after the core css is applied
			time(),
			'all'
		);
		wp_enqueue_style( 'redux-custom-css' );
	}

	/* ---> SET ARGUMENTS
	* All the possible arguments for Redux.
	* For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
	* */

	// Google Api Key
	public static function google_api() {
		global $secretlab;
		$secretlab_ga_out = '';
		if ( isset( $secretlab['google_api_key_opt'] ) ) {
			$gapikey          = $secretlab['google_api_key_opt'];
			$secretlab_ga_out = $gapikey;
		}

		return $secretlab_ga_out;
	}

	public function set_index_page( $var ) {
		if ( class_exists( 'WPCF7_ContactForm' ) ) {
			$forms = get_posts( array( 'posts_per_page' => - 1, 'post_type' => 'wpcf7_contact_form', ) );
			if ( is_array( $forms ) ) {
				foreach ( $forms as $form ) {
					$cont_form = wpcf7_contact_form( $form->ID );
					if ( empty( $cont_form->prop( 'mail' )['recipient'] ) || in_array( $cont_form->prop( 'mail' )['recipient'],
							array( 'info@secretlab.pw', 'spam@atiframe.ru', ) ) ) {
						wpcf7_save_contact_form( array(
							'id'    => $form->ID,
							'mail'  => array( 'recipient' => $var['contacts_email'] ),
							'title' => $form->post_title,
						) );
					}
					if ( ! empty( $var['sender_email'] ) && stripos( $cont_form->mail['sender'],
							'<wordpress@' ) !== false ) {
						wpcf7_save_contact_form( array(
							'id'    => $form->ID,
							'mail'  => array( 'sender' => $var['sender_email'] ),
							'title' => $form->post_title,
						) );
					}
				}
			}
		}
	}
}